# Prompts para editar y corregir el ADD en Word

Dos formas de uso:
- **Agente o chat** (con `04_instrucciones_agente_editor_add.md` y `05_referencia_add_process_one.md`): adjunta el Word vigente y la fuente del cambio; recibes los cambios por sección listos para pegar.
- **Copilot dentro de Word** (con el ADD abierto): usa los prompts cortos de la parte B; Copilot edita el documento directamente. Revisa cada cambio con "Control de cambios" activado (Revisar → Control de cambios).

Reemplaza lo que está entre [corchetes].

---

## A. Prompts para el agente o chat

### A1. Actualizar la definición de APIs con el WSDL o la documentación de OnBase

```text
Adjunto el ADD vigente y [WSDL / manual de API de OnBase versión X].
1. Extrae el catálogo de operaciones SOAP relevantes para: listar documentos por tipo y fecha, obtener metadatos, descargar el binario, obtener adjuntos/relacionados y crear una revisión no vigente. Cita archivo y sección de cada una.
2. Completa la plantilla de definición de API (referencia §3) para cada operación TMF667 v4 de la fachada.
3. Aplica el mapa de dependencias "Una API u operación" y entrégame los cambios por sección: 4.3.1 a) b), 4.5 INT-01 a INT-05, 5.2, 5.3 mapeo, 5.6, 6.3, 6.7 (recalcula llamadas y horas de carga), 7.1, 7.3, ADR-02/09, RSK-01/04, PEN-01 a PEN-04 (cerrar los resueltos), SU-05/06.
4. Indica qué vistas ArchiMate cambian (05, 06, 07).
```

### A2. Alinear la fachada con la especificación TMF667 v4 oficial

```text
Adjunto la especificación TMF667 Document Management v4.[x] y el ADD.
Contrasta lo que dice el ADD (4.3.1 a, 4.5, 5.3, 5.6) con la especificación: rutas, nombres de operaciones, atributos del recurso Document, tipos de relación y manejo de errores.
Entrega: tabla de diferencias (ADD dice / la especificación dice / corrección), cambios por sección y lista de extensiones que debemos declarar.
```

### A3. Completar datos levantados en sitio

```text
Estos son datos confirmados en sitio: [pego lista: dato = valor, fuente].
Reemplaza los marcadores correspondientes en todo el ADD (dime cada sección donde aparece), cierra los PEN resueltos, ajusta riesgos que bajen de nivel y agrega la fila de bitácora.
Los datos confidenciales (IPs, cuentas) solo en las tablas técnicas 6.3 y 7.1; nunca contraseñas ni certificados.
```

### A4. Registrar una decisión de arquitectura

```text
Decisión tomada: [descripción], alternativas evaluadas: [lista], motivo: [texto], aprobada por [rol] el [fecha].
Agrega o actualiza el ADR en la sección 9 y propaga el cambio a las secciones que la decisión afecta (mapa de dependencias). Si reemplaza una decisión anterior, márcala como "Reemplazada por ADR-xx".
```

### A5. Incorporar o cambiar un componente

```text
Cambio de arquitectura: [se agrega / se reemplaza / se retira] [componente] que [función]. Se integra con [componentes] por [protocolo] y corre en [plataforma].
Entrega los cambios en 1.3, 4.1, 4.3, 4.3.1, 4.4, 4.5, 4.6, 6.1, 6.2, 6.5, 6.6, 7.1, un ADR nuevo, GAP en 10.1 y los fragmentos XML ArchiMate para las vistas 05, 06, 07 y 09.
```

### A6. Revisión de consistencia completa

```text
Revisa el ADD adjunto de punta a punta y dame una tabla de hallazgos (sección, problema, corrección propuesta) sobre:
IDs duplicados o saltados · referencias a figuras, tablas, ADR, PEN o RSK inexistentes · datos que se contradicen entre secciones (cuotas, volúmenes, versiones, nombres de componentes) · marcadores sin registrar en la sección 13 · requisitos sin criterio medible · tablas con columnas distintas a las del formato.
Luego entrega solo las correcciones como cambios por sección.
```

### A7. Preparar una nueva versión

```text
Prepara la versión [0.9.x / 1.0] del ADD con los cambios de esta sesión: [resumen].
Entrega: fila de bitácora, datos de portada, lista de secciones modificadas, estado de pendientes (abiertos/cerrados) y checklist del Anexo D actualizado. Para 1.0 verifica que no queden marcadores.
```

### A8. Ajustar al comentario de un revisor

```text
El revisor [rol] comentó: "[texto]". Evalúa si procede, propón la corrección y aplícala en todas las secciones afectadas. Si no procede, redacta la respuesta al comentario con la justificación.
```

### A9. Definir los 18 agentes con información real

```text
Con esta información del área [pego criterios, plantillas, normas, ejemplos], completa el Anexo E para los agentes [AG-xx]: responsabilidad, modelo, herramientas, instrucciones resumidas y criterios de aceptación medibles. Actualiza 4.3.1 e), 5.6 (salida de agentes), RNF-08/09 y cierra PEN-07 si queda completo.
```

---

## B. Prompts cortos para Copilot dentro de Word

Pega uno por vez con el ADD abierto y el Control de cambios activado.

```text
En la tabla de la sección 4.5, reemplaza la celda "Operación" de la fila INT-02 por: [texto].
```
```text
Agrega una fila al final de la tabla de la sección 9 con: ADR-12 | [Decisión] | [Contexto] | [Alternativas] | [Justificación] | [Consecuencias] | Propuesta | [dd/mm/aaaa].
```
```text
Busca en todo el documento el texto {{IP_GATEWAY}} y reemplázalo por [valor]. Quita el resaltado amarillo solo en esas apariciones.
```
```text
En la sección 13, cambia el Estado de PEN-02 a "Cerrado" y agrega en la columna "Pendiente / Definición": "Resuelto: [detalle] ([fuente])".
```
```text
Agrega una fila a la bitácora del documento: 4 | J. Ayala | [dd/mm/aaaa] | [Descripción del cambio] | v0.9.3. Actualiza la versión de la portada a v0.9.3.
```
```text
Revisa la sección 4.3.1 b) y reescribe la viñeta de "Modos" con estos datos: [volumen, llamadas, tiempo]. Mantén el estilo del resto de viñetas.
```
```text
Lista todas las apariciones de "{{" que quedan en el documento, con la sección donde están.
```
```text
Reemplaza la imagen de la Figura [n] por la imagen que pegaré a continuación y conserva el pie de figura.
```
