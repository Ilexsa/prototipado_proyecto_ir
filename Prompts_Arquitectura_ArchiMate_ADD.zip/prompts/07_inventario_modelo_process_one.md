# Inventario del modelo ArchiMate de Process One (ProcessOne_ArchiMate_v0.9.2.xml)

Úsalo para referenciar elementos existentes al modificar el XML. Todos los identifiers del XML llevan prefijo: elemento `id-<id>`; relación `id-r-<tipo3>-<origen>-<destino>[-<nombre>]` (tipo3 = primeras 3 letras en minúscula: com, agg, ass, rea, ser, acc, flo, tri, inf, spe); vista `id-v-<vista>`; nodo `id-v-<vista>-n-<id o alias>`; conexión `id-v-<vista>-c-<nodo origen>-<nodo destino>-<tipo3>`.

Ejemplos reales: elemento `id-ac_ing` · relación `id-r-rea-ac_ing-as_carga` · relación con nombre `id-r-flo-ac_gw-ac_ing-document-tmf667` · nodo `id-v-v05-n-ac_ing` · conexión `id-v-v05-c-ac_ing-as_carga-rea`.

Para confirmar un identifier, búscalo en el XML (Ctrl+F). Los nodos repetidos de un mismo elemento usan alias, p. ej. `id-v-v02-n-rol_ip-2`.

## Elementos (98)

| id (sin prefijo) | Tipo | Nombre |
| --- | --- | --- |
| rol_sol | BusinessRole | Solicitante |
| rol_ip | BusinessRole | Ingeniero de Procesos |
| rol_jip | BusinessRole | Jefe de Ingeniería de Procesos |
| rol_area | BusinessRole | Áreas involucradas |
| rol_ger | BusinessRole | Gerentes de las áreas |
| rol_gcias | BusinessRole | Gerencias (Procesos, Operaciones e involucradas) |
| rol_aob | BusinessRole | Administrador de OnBase |
| rol_col | BusinessRole | Colaboradores |
| p01 | BusinessProcess | 1. Solicitud de actualización (ticket SGP) |
| p02 | BusinessProcess | 2. Validación de la solicitud |
| p03 | BusinessProcess | 3. Asignación a un Ingeniero de Procesos |
| p04 | BusinessProcess | 4. Identificación de áreas, procesos y documentos |
| p05 | BusinessProcess | 5. Sesiones de levantamiento |
| p06 | BusinessProcess | 6. Análisis y generación del borrador |
| p07 | BusinessProcess | 7. Revisión por las áreas |
| p08 | BusinessProcess | 8. Aprobación de gerencias |
| p09 | BusinessProcess | 9. Socialización con gerencias |
| p10 | BusinessProcess | 10. Carga en OnBase y publicación |
| p11 | BusinessProcess | 11. Comunicación formal |
| bp_act | BusinessProcess | Actualización de procesos y manuales |
| ev_ini | BusinessEvent | Necesidad de actualizar un proceso |
| ev_fin | BusinessEvent | Documento actualizado y comunicado |
| cap01 | Capability | Gestión de solicitudes de actualización |
| cap02 | Capability | Análisis de impacto documental |
| cap03 | Capability | Consulta de conocimiento documental |
| cap04 | Capability | Análisis documental asistido por IA |
| cap05 | Capability | Redacción y revisión de borradores (HITL) |
| cap06 | Capability | Revisión y aprobación documental |
| cap07 | Capability | Comunicación de cambios de procesos |
| cap08 | Capability | Gestión del repositorio documental oficial |
| cap09 | Capability | Integración estándar con OnBase (TMF667) |
| cap10 | Capability | Base de conocimiento documental (RAG) |
| cap11 | Capability | Comunicación formal de actualizaciones |
| grp_sin | Grouping | Sin cambio (verde) |
| grp_mod | Grouping | Modificar (naranja) |
| grp_new | Grouping | Nueva (rojo) |
| ac_onb | ApplicationComponent | OnBase |
| ac_sgp | ApplicationComponent | SGP |
| ac_mail | ApplicationComponent | Correo y Word |
| ac_gw | ApplicationComponent | API Gateway – fachada TMF667 v4 |
| ac_ing | ApplicationComponent | API de Ingesta de OnBase |
| ac_back | ApplicationComponent | Backend de Process One |
| ac_web | ApplicationComponent | Process One Web |
| ac_srch | ApplicationComponent | Azure AI Search – índice RAG |
| ac_mas | ApplicationComponent | Sistema multiagente (18 agentes) |
| ac_cbot | ApplicationComponent | Chatbot de Process One |
| ai_soap | ApplicationInterface | API SOAP de OnBase |
| ai_tmf | ApplicationInterface | API TMF667 Document Management v4 |
| ai_papi | ApplicationInterface | API de Process One (REST) |
| ai_web | ApplicationInterface | Interfaz web de Process One |
| ai_chat | ApplicationInterface | Canal Teams / web |
| as_ident | ApplicationService | Identificación de documentos impactados |
| as_consulta | ApplicationService | Consulta de manuales con cita |
| as_analisis | ApplicationService | Análisis documental y borrador |
| as_hitl | ApplicationService | Gestión de borradores y aprobaciones |
| as_carga | ApplicationService | Carga controlada a OnBase |
| as_ingesta | ApplicationService | Ingesta y sincronización documental |
| as_rag | ApplicationService | Búsqueda híbrida con cita (RAG) |
| as_repo | ApplicationService | Gestión documental OnBase |
| as_tick | ApplicationService | Registro de solicitudes |
| col_ing | ApplicationCollaboration | Ingesta y conocimiento |
| col_ana | ApplicationCollaboration | Análisis documental |
| col_con | ApplicationCollaboration | Consulta conversacional |
| col_car | ApplicationCollaboration | Carga controlada |
| do_doc | DataObject | Document (TMF667) |
| do_att | DataObject | Attachment |
| do_rel | DataObject | DocumentRelationship |
| do_ver | DataObject | Versión de documento |
| do_frag | DataObject | Fragmento (texto + vector) |
| do_sol | DataObject | Solicitud (ticket SGP) |
| do_eje | DataObject | Ejecución de análisis |
| do_hal | DataObject | Hallazgo |
| do_bor | DataObject | Borrador |
| do_apr | DataObject | Aprobación |
| do_car | DataObject | Carga a OnBase |
| loc_dc | Location | Centro de datos (on-premises) |
| loc_az | Location | Microsoft Azure – {{Región}} |
| loc_m365 | Location | Microsoft 365 |
| n_obs | Node | Servidor OnBase |
| n_gws | Node | Servidor API Gateway |
| d_fw | Device | Firewall / concentrador VPN |
| n_sgp | Node | Servidor SGP |
| cn_lan | CommunicationNetwork | LAN corporativa |
| p_vpn | Path | VPN site-to-site IPsec/IKEv2 |
| n_vgw | Node | Azure VPN Gateway |
| cn_vnet | CommunicationNetwork | VNet Process One (Private Endpoints) |
| n_aca | Node | Azure Container Apps Environment (interno) |
| n_blob | Node | Azure Blob Storage |
| n_srch | Node | Azure AI Search |
| n_fdy | Node | Microsoft Foundry + Azure OpenAI |
| n_kv | Node | Azure Key Vault |
| n_db | Node | Base de datos operativa (por definir) |
| n_mon | Node | Azure Monitor / App Insights |
| n_entra | Node | Microsoft Entra ID |
| n_cps | Node | Copilot Studio |
| grp_neg | Grouping | Negocio |
| grp_si | Grouping | Sistemas de información |
| grp_tec | Grouping | Tecnología |

## Vistas (9)

| Vista (identifier) | Nombre | Viewpoint | Nodos |
| --- | --- | --- | --- |
| id-v-v01 | 01 Evaluación de capacidades | Capability Map | grp_sin, cap01, cap07, cap11, grp_mod, cap05, cap06, cap08, grp_new, cap02, cap03, cap04, cap09, cap10 |
| id-v-v02 | 02 Proceso AS-IS – actualización de procesos y manuales | Business Process Cooperation | ev_ini, p01, p02, p03, p04, p05, p06, p07, p08, p09, p10, p11, ev_fin, rol_sol, rol_ip@2, rol_jip, rol_ip@4, rol_ip@5, rol_ip@6, rol_area, rol_ger, rol_gcias, rol_aob, rol_ip@10, rol_ip@11, as_tick, as_repo |
| id-v-v03 | 03 Proceso TO-BE – con Process One | Business Process Cooperation | ev_ini, p01, p02, p03, p04, p05, p06, p07, p08, p09, p10, p11, ev_fin, rol_sol, rol_ip@2, rol_jip, rol_ip@4, rol_ip@5, rol_ip@6, rol_area, rol_ger, rol_gcias, rol_aob, rol_ip@10, rol_ip@11, as_ident, as_consulta, as_analisis, as_hitl, as_carga, as_tick |
| id-v-v04 | 04 Arquitectura AS-IS por capas | Layered | grp_neg, rol_ip, rol_jip, bp_act, grp_si, as_tick, as_repo, ac_sgp, ac_mail, ac_onb, grp_tec, n_sgp, n_obs |
| id-v-v05 | 05 Arquitectura TO-BE por capas | Layered | grp_neg, p04, p05, p06, p07, p10, grp_si, as_ident, as_consulta, as_analisis, as_hitl, as_rag, as_carga, ac_cbot, ac_mas, ac_back, ac_srch, ac_ing, ac_web, ai_tmf, ac_gw, ac_onb, grp_tec, n_cps, n_fdy, n_aca, n_blob, n_srch, p_vpn, n_gws, n_obs |
| id-v-v06 | 06 Intercambio de información | Application Cooperation | ac_onb, ac_gw, ac_ing, ac_srch, ac_back, ac_mas, ac_web, ac_cbot, do_doc, do_ver, do_frag, do_hal, do_bor, do_car |
| id-v-v07 | 07 Colaboraciones entre aplicaciones | Application Cooperation | col_ing, ac_gw@1, ac_ing@1, ac_srch@1, col_ana, ac_web@2, ac_back@2, ac_mas@2, ac_srch@2, col_con, ac_cbot@3, ac_mas@3, ac_srch@3, col_car, ac_web@4, ac_back@4, ac_ing@4, ac_gw@4, ac_onb@4 |
| id-v-v08 | 08 Modelo de datos | Information Structure | do_rel, do_doc, do_att, do_ver, do_frag, do_sol, do_eje, do_hal, do_bor, do_apr, do_car |
| id-v-v09 | 09 Despliegue | Technology | loc_dc, n_obs, n_gws, n_sgp, d_fw, cn_lan, p_vpn, loc_az, n_vgw, n_aca, n_fdy, cn_vnet, n_blob, n_srch, n_kv, n_db, n_mon, loc_m365, n_entra, n_cps |

Nota: en el XML, los alias de nodo con "@" se escriben con "-" (rol_ip@2 → rol_ip-2).
