# Referencia ArchiMate 3.2 · Open Exchange Format (OEF) · TOGAF 10

Documento de conocimiento para el agente de diagramas. Sirve para cualquier modelo, no solo Process One.

## 1. Esqueleto de un archivo OEF válido

```xml
<?xml version="1.0" encoding="UTF-8"?>
<model xmlns="http://www.opengroup.org/xsd/archimate/3.0/"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.opengroup.org/xsd/archimate/3.0/ http://www.opengroup.org/xsd/archimate/3.1/archimate3_Diagram.xsd"
       identifier="id-model-miproyecto">
  <name xml:lang="es">Mi proyecto – ArchiMate 3.2</name>
  <documentation xml:lang="es">Descripción del modelo.</documentation>
  <elements> … </elements>
  <relationships> … </relationships>
  <organizations> … </organizations>            <!-- opcional -->
  <propertyDefinitions> … </propertyDefinitions> <!-- solo si hay propiedades -->
  <views><diagrams> … </diagrams></views>
</model>
```
El orden de las secciones es obligatorio. Un modelo nuevo puede tener solo elements, relationships y views.

## 2. Sintaxis de cada pieza

**Elemento (con documentación y propiedad opcionales):**
```xml
<element identifier="id-ac_crm" xsi:type="ApplicationComponent">
  <name xml:lang="es">CRM Corporativo</name>
  <documentation xml:lang="es">Gestión de clientes.</documentation>
  <properties>
    <property propertyDefinitionRef="propid-estado"><value xml:lang="es">Existente</value></property>
  </properties>
</element>
```

**Definición de propiedad** (una por clave, dentro de `<propertyDefinitions>`):
```xml
<propertyDefinition identifier="propid-estado" type="string"><name xml:lang="es">Estado</name></propertyDefinition>
```

**Relaciones:**
```xml
<relationship identifier="id-r-ser-as_consulta-bp_venta" source="id-as_consulta" target="id-bp_venta" xsi:type="Serving" />
<relationship identifier="id-r-acc-ac_crm-do_cliente" source="id-ac_crm" target="id-do_cliente" xsi:type="Access" accessType="Write" />
<relationship identifier="id-r-flo-ac_a-ac_b-pedido" source="id-ac_a" target="id-ac_b" xsi:type="Flow"><name xml:lang="es">Pedido</name></relationship>
<relationship identifier="id-r-ass-rol_x-ac_y" source="id-rol_x" target="id-ac_y" xsi:type="Association" isDirected="true" />
```
Tipos de elemento válidos (xsi:type): Stakeholder, Driver, Assessment, Goal, Outcome, Principle, Requirement, Constraint, Meaning, Value · Resource, Capability, ValueStream, CourseOfAction · BusinessActor, BusinessRole, BusinessCollaboration, BusinessInterface, BusinessProcess, BusinessFunction, BusinessInteraction, BusinessEvent, BusinessService, BusinessObject, Contract, Representation, Product · ApplicationComponent, ApplicationCollaboration, ApplicationInterface, ApplicationFunction, ApplicationInteraction, ApplicationProcess, ApplicationEvent, ApplicationService, DataObject · Node, Device, SystemSoftware, TechnologyCollaboration, TechnologyInterface, Path, CommunicationNetwork, TechnologyFunction, TechnologyProcess, TechnologyInteraction, TechnologyEvent, TechnologyService, Artifact, Equipment, Facility, DistributionNetwork, Material · WorkPackage, Deliverable, ImplementationEvent, Plateau, Gap · Location, Grouping, AndJunction, OrJunction.

**Vista (diagrama) con un contenedor, dos nodos y una conexión con quiebre:**
```xml
<view identifier="id-v-integracion" xsi:type="Diagram" viewpoint="Application Cooperation">
  <name xml:lang="es">Integración de ventas</name>
  <documentation xml:lang="es">Preocupación: … · Interesado: … · Fase ADM: C (Aplicación)</documentation>
  <node identifier="id-v-integracion-n-grp_az" elementRef="id-grp_az" xsi:type="Element" x="20" y="20" w="460" h="140">
    <style><fillColor r="250" g="250" b="250" /><lineColor r="92" g="92" b="92" /><font name="Segoe UI" size="9"><color r="0" g="0" b="0" /></font></style>
    <node identifier="id-v-integracion-n-ac_a" elementRef="id-ac_a" xsi:type="Element" x="40" y="70" w="150" h="55">
      <style><fillColor r="181" g="255" b="255" /><lineColor r="92" g="92" b="92" /><font name="Segoe UI" size="9"><color r="0" g="0" b="0" /></font></style>
    </node>
    <node identifier="id-v-integracion-n-ac_b" elementRef="id-ac_b" xsi:type="Element" x="310" y="70" w="150" h="55">
      <style><fillColor r="181" g="255" b="255" /><lineColor r="92" g="92" b="92" /><font name="Segoe UI" size="9"><color r="0" g="0" b="0" /></font></style>
    </node>
  </node>
  <connection identifier="id-v-integracion-c-ac_a-ac_b-flo" relationshipRef="id-r-flo-ac_a-ac_b-pedido" xsi:type="Relationship"
              source="id-v-integracion-n-ac_a" target="id-v-integracion-n-ac_b">
    <bendpoint x="250" y="97" />
  </connection>
</view>
```
Reglas: x,y son absolutas respecto del diagrama también en nodos anidados; un hijo debe quedar dentro del rectángulo de su padre; `<style>` es opcional (si falta, Archi usa sus colores). Un mismo elemento puede tener varios nodos en una vista (identifiers distintos, p. ej. `-n-rol_x-2`).

**Organización (carpetas en Archi, opcional):**
```xml
<item><label xml:lang="es">Aplicación</label>
  <item identifierRef="id-ac_crm" />
</item>
```

**Valores válidos de `viewpoint`:** Organization, Application Platform, Application Structure, Information Structure, Technology, Layered, Physical, Product, Application Usage, Technology Usage, Business Process Cooperation, Application Cooperation, Service Realization, Implementation and Deployment, Goal Realization, Goal Contribution, Principles, Requirements Realization, Motivation, Strategy, Capability Map, Outcome Realization, Resource Map, Value Stream, Project, Migration, Implementation and Migration, Stakeholder. (Omitir el atributo = vista libre.)

**Colores de relleno por capa (RGB):** Motivación 204,204,255 · Estrategia 245,222,170 · Negocio 255,255,181 · Aplicación 181,255,255 · Tecnología/física 201,231,183 · Implementación 255,224,224 · Migración 224,255,224 · Location 251,184,117 · Grouping 250,250,250.

## 3. Relaciones permitidas (ArchiMate 3.2, tabla oficial – pares más usados)

Association es válida entre casi cualquier par. Specialization solo entre elementos del mismo tipo. Grouping puede agregar/componer cualquier elemento. Si un par no está en esta tabla, usa Association o pide confirmación: no supongas.

| Origen | Destino | Relaciones permitidas |
| --- | --- | --- |
| Stakeholder | Driver | Association, Influence |
| Driver | Goal | Association, Influence |
| Assessment | Driver | Association, Influence |
| Goal | Outcome | Association, Influence |
| Outcome | Goal | Realization, Association, Influence |
| Principle | Requirement | Association, Influence |
| Requirement | Goal | Realization, Association, Influence |
| Constraint | Requirement | Composition, Aggregation, Specialization, Association, Influence |
| BusinessProcess | Requirement | Realization, Association, Influence |
| ApplicationComponent | Requirement | Realization, Association, Influence |
| Node | Requirement | Realization, Association, Influence |
| Capability | Capability | Composition, Aggregation, Specialization, Triggering, Flow, Serving, Association |
| BusinessProcess | Capability | Realization, Association |
| ApplicationComponent | Capability | Realization, Association |
| Resource | Capability | Assignment, Triggering, Flow, Serving, Association |
| ValueStream | Capability | Triggering, Flow, Serving, Association |
| Capability | ValueStream | Triggering, Flow, Serving, Association |
| CourseOfAction | Capability | Triggering, Flow, Serving, Association |
| Capability | Outcome | Realization, Association, Influence |
| BusinessActor | BusinessRole | Assignment, Triggering, Flow, Serving, Association |
| BusinessRole | BusinessProcess | Assignment, Triggering, Flow, Serving, Association |
| BusinessRole | BusinessFunction | Assignment, Triggering, Flow, Serving, Association |
| BusinessProcess | BusinessProcess | Composition, Aggregation, Specialization, Triggering, Flow, Serving, Association |
| BusinessEvent | BusinessProcess | Triggering, Flow, Serving, Association |
| BusinessProcess | BusinessEvent | Triggering, Flow, Serving, Association |
| BusinessProcess | BusinessService | Realization, Triggering, Flow, Serving, Association |
| BusinessService | BusinessRole | Triggering, Flow, Serving, Association |
| BusinessProcess | BusinessObject | Association, Access |
| BusinessFunction | BusinessProcess | Composition, Aggregation, Triggering, Flow, Serving, Association |
| BusinessCollaboration | BusinessRole | Aggregation, Assignment, Triggering, Flow, Serving, Association |
| BusinessInterface | BusinessRole | Triggering, Flow, Serving, Association |
| ApplicationComponent | ApplicationComponent | Composition, Aggregation, Realization, Specialization, Triggering, Flow, Serving, Association |
| ApplicationComponent | ApplicationService | Assignment, Realization, Triggering, Flow, Serving, Association |
| ApplicationComponent | ApplicationInterface | Composition, Aggregation, Realization, Triggering, Flow, Serving, Association |
| ApplicationComponent | ApplicationFunction | Assignment, Realization, Triggering, Flow, Serving, Association |
| ApplicationFunction | ApplicationService | Realization, Triggering, Flow, Serving, Association |
| ApplicationService | BusinessProcess | Triggering, Flow, Serving, Association |
| ApplicationService | BusinessRole | Triggering, Flow, Serving, Association |
| ApplicationService | ApplicationComponent | Triggering, Flow, Serving, Association |
| ApplicationInterface | BusinessRole | Triggering, Flow, Serving, Association |
| ApplicationInterface | ApplicationComponent | Triggering, Flow, Serving, Association |
| ApplicationComponent | BusinessProcess | Realization, Triggering, Flow, Serving, Association |
| ApplicationCollaboration | ApplicationComponent | Aggregation, Realization, Triggering, Flow, Serving, Association |
| ApplicationCollaboration | ApplicationInteraction | Assignment, Realization, Triggering, Flow, Serving, Association |
| ApplicationComponent | DataObject | Association, Access |
| ApplicationService | DataObject | Association, Access |
| ApplicationProcess | DataObject | Association, Access |
| DataObject | BusinessObject | Realization, Association |
| DataObject | DataObject | Composition, Aggregation, Specialization, Association |
| ApplicationEvent | ApplicationProcess | Triggering, Flow, Serving, Association |
| ApplicationProcess | ApplicationService | Realization, Triggering, Flow, Serving, Association |
| Node | Node | Composition, Aggregation, Assignment, Specialization, Triggering, Flow, Serving, Association |
| Device | Node | Triggering, Flow, Serving, Association |
| Node | SystemSoftware | Composition, Aggregation, Assignment, Realization, Triggering, Flow, Serving, Association |
| SystemSoftware | SystemSoftware | Composition, Aggregation, Assignment, Realization, Specialization, Triggering, Flow, Serving, Association |
| Node | ApplicationComponent | Realization, Triggering, Flow, Serving, Association |
| SystemSoftware | ApplicationComponent | Realization, Triggering, Flow, Serving, Association |
| Node | TechnologyService | Assignment, Realization, Triggering, Flow, Serving, Association |
| TechnologyService | ApplicationComponent | Triggering, Flow, Serving, Association |
| Node | TechnologyInterface | Composition, Aggregation, Assignment, Realization, Triggering, Flow, Serving, Association |
| Node | Artifact | Assignment, Association, Access |
| Artifact | ApplicationComponent | Realization, Association |
| Artifact | DataObject | Realization, Association |
| Node | CommunicationNetwork | Triggering, Flow, Serving, Association |
| Path | Node | Aggregation, Assignment, Triggering, Flow, Serving, Association |
| Location | Node | Composition, Aggregation, Assignment, Realization, Triggering, Flow, Serving, Association |
| Location | ApplicationComponent | Composition, Aggregation, Realization, Triggering, Flow, Serving, Association |
| Location | BusinessActor | Composition, Aggregation, Assignment, Realization, Triggering, Flow, Serving, Association |
| Grouping | ApplicationComponent | Composition, Aggregation, Realization, Specialization, Triggering, Flow, Serving, Association |
| Grouping | Node | Composition, Aggregation, Assignment, Realization, Specialization, Triggering, Flow, Serving, Association |
| WorkPackage | Deliverable | Realization, Association, Access |
| Deliverable | ApplicationComponent | Realization, Association |
| Deliverable | Plateau | Realization, Association |
| Plateau | Plateau | Composition, Aggregation, Specialization, Triggering, Flow, Association |
| Gap | Plateau | Association |
| Plateau | ApplicationComponent | Composition, Aggregation, Realization, Association |
| WorkPackage | WorkPackage | Composition, Aggregation, Specialization, Triggering, Flow, Association |
| BusinessRole | WorkPackage | Assignment, Association |
| ImplementationEvent | WorkPackage | Triggering, Flow, Association |
**Alternativas cuando una relación no está permitida (errores frecuentes):**
| Querías | Usa en su lugar |
| --- | --- |
| Composition Node → ApplicationComponent | Node Realization/Serving → ApplicationComponent, o Node Assignment → Artifact + Artifact Realization → ApplicationComponent |
| ApplicationComponent Assignment → BusinessProcess | ApplicationComponent Realization → ApplicationService + ApplicationService Serving → BusinessProcess |
| BusinessRole Serving → BusinessProcess | BusinessRole Assignment → BusinessProcess |
| DataObject Flow → DataObject | Flow entre los componentes/procesos que intercambian el dato (nómbrala con el dato) |
| Requirement → componente | Componente Realization → Requirement |
| Stakeholder → Goal | Stakeholder Association/Influence → Driver; Driver Influence → Goal |

## 4. Diagramas por fase del ADM de TOGAF 10 → viewpoint ArchiMate

| Fase ADM | Diagrama TOGAF | Viewpoint ArchiMate | Elementos principales |
| --- | --- | --- | --- |
| Preliminar | Principios de arquitectura | Principles | Principle, Goal, Driver |
| A Visión | Mapa de interesados / motivadores | Stakeholder, Motivation | Stakeholder, Driver, Assessment, Goal, Outcome |
| A Visión | Concepto de solución | Layered (alto nivel) | Capability, BusinessService, ApplicationComponent, Node |
| A / B | Mapa de capacidades | Capability Map | Capability, Grouping (por dominio o semáforo) |
| A / B | Cadena / flujo de valor | Value Stream | ValueStream, Capability, Outcome |
| B Negocio | Huella de negocio (Business Footprint) | Layered | Goal, BusinessFunction, BusinessService, ApplicationComponent |
| B Negocio | Flujo de proceso | Business Process Cooperation | BusinessEvent, BusinessProcess, BusinessRole, BusinessObject, ApplicationService |
| B Negocio | Organización | Organization | BusinessActor, BusinessRole, Location, BusinessCollaboration |
| C Datos | Modelo conceptual / lógico de datos | Information Structure | BusinessObject, DataObject, Realization entre ellos |
| C Datos | Difusión de datos | Application Cooperation | ApplicationComponent, DataObject (Access), Flow nombrados |
| C Aplicación | Comunicación de aplicaciones | Application Cooperation | ApplicationComponent, ApplicationInterface, Flow, ApplicationCollaboration |
| C Aplicación | Realización proceso ↔ aplicación | Application Usage / Service Realization | BusinessProcess, ApplicationService, ApplicationComponent |
| C Aplicación | Estructura de una aplicación | Application Structure | ApplicationComponent (Composition), ApplicationInterface, ApplicationFunction, DataObject |
| D Tecnología | Entornos y ubicaciones / despliegue | Technology, Implementation and Deployment | Location, Node, Device, SystemSoftware, Artifact, CommunicationNetwork, Path |
| D Tecnología | Uso de tecnología | Technology Usage | ApplicationComponent, TechnologyService, Node |
| D Tecnología | Red / comunicaciones | Physical, Technology | Node, Device, CommunicationNetwork, Path, Equipment |
| E / F | Proyecto y migración | Implementation and Migration, Migration, Project | WorkPackage, Deliverable, Plateau, Gap, ImplementationEvent |
| G Gobierno | Trazabilidad de requisitos | Requirements Realization | Requirement, Constraint, componente que la realiza |

Cada vista lleva en `<documentation>`: preocupación, interesado principal y fase ADM.

## 5. Reglas de layout (para calcular x, y, w, h)

- Grilla: x = 40 + col × 190 ; y = 40 + fila × 110. Tamaño por defecto w=150, h=55. Nombres de más de 26 caracteres: w=180; más de 3 líneas: h=70.
- Bandas por capa (vista Layered): negocio filas 0–1, aplicación filas 2–4, tecnología filas 5–6; motivación a la izquierda (columnas negativas o una banda superior).
- Contenedor (Grouping, Location, componente que compone a otros): x = min(x hijos) − 20; y = min(y hijos) − 35; w = max(x+w hijos) − x + 20; h = max(y+h hijos) − y + 20.
- Flujos de izquierda a derecha; servicios encima de quien los realiza; quien sirve (Serving) apunta hacia arriba (tecnología → aplicación → negocio).
- Si la línea recta entre dos nodos atraviesa otro nodo, agrega bendpoints ortogonales en coordenadas absolutas (por el pasillo entre columnas: x = 40 + col × 190 + 170).
- No más de ~25 elementos por vista; divide por preocupación.

## 6. Cómo modificar un modelo existente en Archi (sin programar)

1. En Archi: File → Export → Model to Open Exchange File… → guardar `modelo.xml`.
2. Pasar el XML (o las partes relevantes) al agente junto con el pedido.
3. Pegar los fragmentos en los puntos de inserción indicados (un editor de texto con búsqueda basta: Bloc de notas, VS Code o Notepad++).
4. File → Import → Open Exchange XML Model… → se crea un modelo nuevo; revisar las vistas y guardar como `.archimate`.
5. Si Archi muestra un error, copiar el mensaje (trae línea y columna) y dárselo al agente.

Alternativa para cargar muchos elementos y relaciones sin vistas: Archi → File → Import → CSV Data Into Selected Model. Antes exporta un CSV de tu modelo (File → Export → Model To CSV…) para copiar exactamente el formato de columnas y tipos que usa tu versión de Archi, y pide al agente los CSV con ese mismo formato.

## 7. Errores frecuentes al importar

| Mensaje / síntoma | Causa | Solución |
| --- | --- | --- |
| "Package with uri … not found" | Se usó File → Open | Usar File → Import → Open Exchange XML Model |
| ID duplicado / "is not unique" | Identifier repetido | Renombrar con sufijo único |
| Referencia inexistente | elementRef, relationshipRef, source o target que no existe | Crear el elemento/relación o corregir el identifier |
| Conexión no aparece o sale invertida | La relación va en otra dirección que los nodos | Invertir source/target de la conexión o usar otra relación |
| Elemento fuera del contenedor | Coordenadas del hijo fuera del padre | Recalcular el contenedor (regla §5) |
| Error de esquema en `accessType` | Valor inválido | Access, Read, Write o ReadWrite |
