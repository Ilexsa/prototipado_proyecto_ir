# Prompts de arquitectura – ArchiMate y ADD

Funcionan en cualquier IA de chat corporativa (Copilot Studio, Microsoft 365 Copilot, ChatGPT Enterprise u otra con modelos OpenAI). No requieren instalar nada.

## Archivos

| Archivo | Qué es | Dónde va |
| --- | --- | --- |
| 01_instrucciones_agente_archimate.md | Instrucciones del agente de diagramas (≈5.500 caracteres) | Campo "Instrucciones" del agente, o primer mensaje del chat |
| 02_referencia_archimate_oef.md | Sintaxis OEF, relaciones permitidas ArchiMate 3.2, diagramas por fase TOGAF, layout, errores | Conocimiento / archivo adjunto |
| 03_prompts_diagramas.md | 12 prompts listos (vista nueva, modificar, modelo nuevo, migración, revisión, CSV…) | Para ti: copiar y pegar |
| 04_instrucciones_agente_editor_add.md | Instrucciones del agente editor del ADD (≈3.800 caracteres) | Campo "Instrucciones" del agente, o primer mensaje |
| 05_referencia_add_process_one.md | Estructura del formato, mapa de dependencias entre secciones, plantilla de definición de APIs, figuras ↔ vistas | Conocimiento / adjunto |
| 06_prompts_word.md | Prompts para el agente (A1–A9) y prompts cortos para Copilot dentro de Word | Para ti |
| 07_inventario_modelo_process_one.md | Elementos, vistas y patrones de identifiers del XML v0.9.2 | Conocimiento / adjunto |

## Opción 1 – Copilot Studio (dos agentes)

1. **Agente "Arquitecto ArchiMate"**: instrucciones = 01; conocimiento = 02 y 07. Carga de archivos activada (para adjuntar el XML).
2. **Agente "Editor ADD"**: instrucciones = 04; conocimiento = 05, 07 y 02. Carga de archivos activada (para adjuntar el Word, WSDL, especificación TMF667).
3. Si Copilot Studio rechaza `.md`, cambia la extensión a `.txt`.

## Opción 2 – Chat con proyectos o instrucciones personalizadas (la IA de pago)

1. Crea un proyecto por agente.
2. Pega 01 (o 04) en las instrucciones del proyecto y sube los archivos de referencia.
3. En cada conversación adjunta el XML o el Word vigente y usa un prompt de 03 o 06.

## Opción 3 – Sin agente

Pega el contenido de 01 (o 04) como primer mensaje, adjunta 02 (o 05) y luego envía el prompt.

## Ciclo de trabajo

- **Diagramas:** Archi → File → Export → Model to Open Exchange File → adjuntar al agente con un prompt de 03 → pegar los fragmentos en los puntos de inserción → File → Import → Open Exchange XML Model → guardar como `.archimate`. Si hay error, pegarlo al agente (prompt 03-10).
- **Word:** adjuntar el ADD vigente y la fuente → prompt de 06 → aplicar los cambios (o usar los prompts cortos con Copilot en Word) → actualizar bitácora y versión.
- Mantén el inventario (07) al día: cuando agregues elementos al modelo, pide al agente la lista de elementos nuevos y agrégala al archivo.
