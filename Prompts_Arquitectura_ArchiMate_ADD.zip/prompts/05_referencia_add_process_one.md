# Referencia del ADD de Process One (formato corporativo) – v0.9.2

## 1. Estructura del formato y tablas

| Sección | Tablas del formato (columnas) |
| --- | --- |
| Portada | Iniciativa, Área solicitante, Patrocinador, Líder de arquitectura, Estado, Versión, Fecha |
| Control del documento | Bitácora (#, Autor, Fecha, Descripción del cambio, Versión) · Equipo de trabajo (Actor, Rol, Área, Responsabilidad) · Documentos relacionados (Documento, Descripción, Versión, Ubicación) |
| 1 Preliminar | 1.4 Conceptos (Concepto, Definición); 1.5 Supuestos SU-xx (viñetas); 1.6 Dependencias (viñetas) |
| 2 Visión | 2.2 Interesados · 2.3 OBJ · 2.4 DRV · 2.5 PR · 2.6 etapas del proceso (no aplica cadena de valor) · 2.7 capacidades (semáforo) · 2.8 RES · 2.9 RSK · 2.10 roadmap · 2.11 aprobación |
| 3 Negocio | 3.1 BB-N · 3.2 No aplica · 3.3 escenarios · 3.4 proceso (Figuras 3–6) · 3.5 actores · 3.6 RN · 3.7 RNQ · 3.8 RSK-N |
| 4 Sistemas de información | 4.2 AS-IS (Fig. 7) · 4.3 TO-BE (Fig. 8) y 4.3.1 diseño y construcción (a–h) · 4.4 BB-A · 4.5 INT (ID, Proveedor, Consumidor, Servicio/Interfaz, Operación, Protocolo, Autenticación, Datos principales, SLA) · 4.6 colaboraciones (Fig. 9) · 4.7 reglas de modelado |
| 5 Datos | 5.1 dominios · 5.2 DAT (Fig. 10) · 5.3 entidades (Fig. 11) + mapeo OnBase ↔ TMF667 · 5.4 calidad · 5.5 privacidad · 5.6 contratos |
| 6 Tecnología | 6.1 despliegue (Fig. 12) · 6.2 TEC · 6.3 conectividad · 6.4 ambientes · 6.5 continuidad · 6.6 monitoreo · 6.7 capacidad |
| 7 Seguridad | 7.1 identidad · 7.2 SEG · 7.3 auditoría · 7.4 cumplimiento |
| 8 RNF | RNF-xx |
| 9 Decisiones | ADR-xx (ID, Decisión, Contexto, Alternativas, Justificación, Consecuencias, Estado, Fecha) |
| 10 Brechas y transición | GAP-xx · fases 0–5 |
| 11 Gestión del cambio | RAW · impacto organizacional |
| 12 Riesgos consolidados | RSK-xx (10 columnas) |
| 13 Pendientes | PEN-xx |
| 14–15 | Conclusiones · Aprobaciones y firmas |
| 16 Anexos | A diagramas · B referencias · C glosario · D checklist · E catálogo de 18 agentes |

**Último ID usado por serie (siguiente = +1):** SU-08 · OBJ-05 · DRV-05 · PR-09 · RES-06 · RSK-11 · RSK-N-04 · BB-N-06 · BB-A-12 · RN-08 · RNQ-08 · INT-12 · DAT-08 · TEC-12 · SEG-09 · RNF-15 · ADR-11 · GAP-08 · PEN-15 · AG-17 · Figura 12.

## 2. Mapa de dependencias (qué más actualizar cuando cambia algo)

| Si cambia… | Actualizar también |
| --- | --- |
| **Una API u operación de OnBase / TMF667** | 4.3.1 a) y b) · 4.5 (INT-01 a INT-05) · 5.2 (DAT-01, DAT-02, DAT-07) · 5.3 mapeo OnBase ↔ TMF667 · 5.6 contrato de la fachada · 6.3 conectividad · 6.7 capacidad (llamadas y tiempo de carga) · 7.1 identidad (cuenta de servicio) · 7.3 auditoría · 9 ADR-02 / ADR-09 · 12 RSK-01 / RSK-04 · 13 PEN-01 a PEN-04 · 1.5 SU-05 / SU-06 · 2.8 RES-01 · vistas ArchiMate 05, 06, 07 · contrato OpenAPI |
| **El límite o la cuota de OnBase** | 1.1 · 2.5 PR-02 · 2.8 RES-01 · 4.3.1 a) b) · 4.5 SLA · 6.7 · 7.2 SEG-03 · 8 RNF-06 · 9 ADR-01 · 12 RSK-01 · 13 PEN-02 |
| **Un componente (nuevo, cambia o se retira)** | 1.3 alcance · 2.1 · 4.1 · 4.3 y 4.3.1 · 4.4 BB-A · 4.5 · 4.6 · 6.1 · 6.2 TEC · 6.5 · 6.6 · 7.1 · 9 ADR nuevo · 10.1 GAP · Anexo A · vistas 05, 06, 07, 09 |
| **Una entidad de datos** | 5.1 · 5.2 · 5.3 · 5.4 · 5.5 · 5.6 · vista 08 (y 06 si cambia quién la accede) |
| **Red, IPs, puertos o VPN** | 6.1 · 6.3 · 7.2 SEG-02 · 13 PEN-05 · vista 09 (Word: completar marcadores; nunca secretos) |
| **Un paso del proceso o un rol** | 2.6 · 2.7 · 3.3 · 3.4 · 3.5 · 3.6 · 3.7 · 11.2 · vistas 02, 03 y láminas BPMN |
| **Una capacidad** | 2.7 · 3.1 BB-N · vista 01 |
| **Un agente de IA** | 4.3.1 e) · Anexo E · 5.6 salida de agentes · 7.2 SEG-06/08 · 8 RNF-08/09 · 13 PEN-07 |
| **Una decisión** | 9 ADR (nuevo o cambio de estado) · secciones que la citan · 12 riesgos asociados · 13 pendiente que la originó |
| **Se resuelve un dato pendiente** | Todas las apariciones del marcador · 13 PEN (Estado: Cerrado) · 12 riesgo asociado si baja |
| **Nueva versión** | Portada (Versión, Fecha, Estado) · encabezado · bitácora · Anexo A si cambian figuras |

## 3. Plantilla de definición de una API (para actualizar 4.5, 5.6 y el contrato)

Por cada operación de la fachada TMF667 v4 completar:

| Campo | Contenido |
| --- | --- |
| Operación TMF667 | listDocument · retrieveDocument · createDocument · patchDocument (u otra de la especificación v4 vigente) |
| Método y ruta | p. ej. `GET /tmf-api/documentManagement/v4/document/{id}` |
| Operación SOAP de OnBase que la implementa | nombre exacto del WSDL + versión de OnBase |
| Parámetros de entrada | nombre, tipo, obligatorio, ejemplo |
| Mapeo de campos | atributo TMF667 ↔ campo/keyword OnBase (ver 5.3) |
| Respuesta | campos devueltos, paginación (offset/limit, X-Total-Count) |
| Errores | 400, 401, 403, 404, 409, 429 (Retry-After), 5xx → objeto Error TMF |
| Costo en cuota | cuántas llamadas SOAP consume cada llamada REST |
| Seguridad | mTLS, IP de origen, cuenta de servicio, permisos en OnBase |
| Auditoría | qué se registra y dónde |
| Extensiones | lo que no está en TMF667 v4 (marcar como extensión) |
| Fuente | archivo y página/sección del WSDL o manual |

Reglas: la versión exacta de TMF667 es la que entregue Integración (v4.x); no se asume ningún atributo que no esté en esa especificación sin marcarlo como extensión. La creación nunca deja un documento en estado vigente (RN-01, ADR-07).

## 4. Figuras del ADD y vistas ArchiMate

| Figura | Contenido | Vista del modelo (ProcessOne_ArchiMate_v0.9.2.xml) |
| --- | --- | --- |
| 1 | Mapa de interesados | — (gráfico poder/interés) |
| 2 | Capacidades por cambio requerido | id-v-v01 |
| 3–4 | Proceso AS-IS (BPMN en carriles) | id-v-v02 |
| 5–6 | Proceso TO-BE (BPMN en carriles) | id-v-v03 |
| 7 | Arquitectura AS-IS por capas | id-v-v04 |
| 8 | Arquitectura TO-BE por capas | id-v-v05 |
| 9 | Colaboraciones entre aplicaciones | id-v-v07 |
| 10 | Intercambio de información | id-v-v06 |
| 11 | Modelo de datos | id-v-v08 |
| 12 | Despliegue | id-v-v09 |

Para actualizar una figura en Word: exportar la vista desde Archi (clic derecho en la vista → Export View As Image… PNG) y reemplazar la imagen conservando el pie de figura.

## 5. Estilo de redacción

- Institucional, impersonal, frases de una idea. Verbos en presente.
- Primera mención de siglas con su significado; luego solo la sigla (glosario en Anexo C).
- Números: separador de miles con punto (1.288) y decimal con coma (4,2 h).
- Marcadores: `{{DATO}}` resaltado en amarillo en Word hasta que se complete.
- No usar "etc.", "y demás" ni "entre otros" en requisitos o criterios de aceptación.
