# Prompts para crear y modificar diagramas ArchiMate

Uso: con el agente configurado con `01_instrucciones_agente_archimate.md` y la referencia `02_referencia_archimate_oef.md` como conocimiento. Si usas un chat sin agente, pega primero el contenido de 01 como mensaje inicial y adjunta 02.

Reemplaza lo que está entre [corchetes]. Adjunta siempre el XML actual del modelo cuando vayas a modificarlo (en Archi: File → Export → Model to Open Exchange File).

---

## 1. Vista nueva dentro del modelo existente

```text
Adjunto el XML actual del modelo [nombre]. Crea una vista nueva:
- Preocupación que responde: [qué pregunta del interesado responde]
- Interesado principal: [quién la usa]
- Fase ADM: [A / B / C-Datos / C-Aplicación / D / E-F]
- Contenido: [lista de elementos o descripción]
Reutiliza los elementos existentes (usa sus identifier del XML). Crea solo los que falten.
Entrégame: tablas de elementos y relaciones con validación, fragmentos XML con punto de inserción (C1, C2, C5) y el checklist.
```

## 2. Modificar una vista existente

```text
Adjunto el XML actual. En la vista [identifier o nombre de la vista]:
- Agregar: [elemento / relación]
- Quitar: [elemento / relación]
- Mover / reorganizar: [qué]
Dame los cambios como BUSCAR / REEMPLAZAR POR sobre el XML actual, más los fragmentos nuevos con su punto de inserción. Si agregas relaciones, valídalas con la tabla ArchiMate 3.2.
```

## 3. Agregar un componente nuevo y propagarlo a todas las vistas donde corresponde

```text
Adjunto el XML actual. Se incorpora el componente [nombre] ([tipo ArchiMate]) que [qué hace], se conecta con [componentes] mediante [API / protocolo] y corre en [nodo/plataforma].
1. Crea el elemento, sus interfaces y servicios si aplica.
2. Crea las relaciones (Flow nombrados, Serving, Realization, Access) validadas.
3. Dime en qué vistas existentes debe aparecer y entrega, por vista, los nodos y conexiones con coordenadas que no se solapen.
```

## 4. Modelo nuevo desde cero para otro proyecto (TOGAF)

```text
Crea un modelo ArchiMate nuevo para el proyecto [nombre]. Contexto: [2–5 líneas o adjunto el ADD/documento].
Entrega el XML completo (desde <?xml hasta </model>) con estas vistas mínimas, una por fase del ADM:
1. Motivación (A): interesados, motivadores, metas, resultados.
2. Mapa de capacidades (A/B) agrupado por [dominio / cambio requerido].
3. Proceso de negocio (B) con roles y servicios de aplicación que lo soportan.
4. Cooperación de aplicaciones (C) con flujos nombrados y objetos de datos.
5. Estructura de información (C-Datos).
6. Despliegue (D) con ubicaciones, nodos y redes.
7. Migración (E/F) con plateaus, brechas y paquetes de trabajo.
Documenta en cada vista: preocupación, interesado y fase. Usa {{MARCADOR}} para datos que no conozcas.
```

## 5. Vista por capas (Layered) a partir de una descripción

```text
Con los elementos del XML adjunto, arma una vista Layered de [alcance]: negocio arriba (procesos del paso [x] al [y] y sus roles), sistemas de información en medio (servicios de aplicación, componentes e interfaces) y tecnología abajo (nodos y redes). Usa Grouping por capa. Relaciones: Serving hacia arriba, Realization de componente a servicio, Flow nombrados entre componentes.
```

## 6. Vista de migración (TOGAF E/F)

```text
Con el XML adjunto y el plan de transición [pego tabla o adjunto], crea una vista Implementation and Migration:
- Plateaus: [Base (AS-IS), Transición 1..n, Objetivo (TO-BE)]
- Gaps entre plateaus
- WorkPackages por fase con sus Deliverables
- Qué componentes realiza cada Deliverable
Valida las relaciones (Triggering entre WorkPackages, Realization de WorkPackage a Deliverable, Realization de Deliverable a componente/Plateau, Association de Gap a Plateaus).
```

## 7. Vista de motivación y trazabilidad de requisitos (A y G)

```text
Con el XML adjunto y la tabla de requisitos [pego RF/RNF], crea:
a) Vista Motivation: Stakeholders → Drivers → Goals → Outcomes → Principles/Requirements.
b) Vista Requirements Realization: cada requisito con el componente, servicio o nodo que lo realiza.
Usa los ID de los requisitos en el nombre (RNF-01 …).
```

## 8. Convertir una tabla del ADD en diagrama

```text
Esta tabla del ADD [pego la tabla: p. ej. 4.5 Servicios, interfaces y APIs / 5.2 Intercambio de información / 6.3 Conectividad] debe quedar reflejada en el modelo.
Crea o actualiza los elementos y relaciones que representa (una fila = una relación nombrada) y una vista [viewpoint] que la muestre. Entrega fragmentos con punto de inserción.
```

## 9. Revisión de un XML antes de importarlo

```text
Revisa el XML adjunto contra el checklist: tipos válidos, relaciones permitidas ArchiMate 3.2, identifiers únicos y existentes, conexiones coherentes con la dirección de la relación, hijos dentro de sus contenedores, viewpoints válidos y XML bien formado.
Entrega una tabla de hallazgos (línea aproximada, identifier, problema, corrección) y los fragmentos corregidos.
```

## 10. Corregir un error de importación de Archi

```text
Archi devolvió este error al importar: [pego el mensaje completo].
Adjunto el XML. Identifica la causa exacta y entrega solo lo que debo reemplazar (BUSCAR / REEMPLAZAR POR).
```

## 11. Carga masiva por CSV (elementos y relaciones sin vistas)

```text
Adjunto un CSV exportado desde mi Archi (File → Export → Model To CSV) como ejemplo de formato. Genera elements.csv, relations.csv y properties.csv con el MISMO formato de columnas y tipos, para agregar: [lista]. Los ID deben ser únicos y no chocar con los existentes.
```

## 12. Reordenar una vista que quedó desordenada

```text
La vista [identifier] del XML adjunto tiene cruces y solapes. Recalcula x, y, w, h con la grilla (x = 40 + col×190, y = 40 + fila×110), agrupa por capa y agrega bendpoints donde una línea atraviese cajas. Entrega la vista completa reemplazada (desde <view … hasta </view>).
```
