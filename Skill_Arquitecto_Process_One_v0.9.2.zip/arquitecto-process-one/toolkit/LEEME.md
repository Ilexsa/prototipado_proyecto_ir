# Toolkit ArchiMate y contratos – Process One

| Archivo | Uso |
|---|---|
| `Generador_ArchiMate_ProcessOne.html` | **Sin instalación**: abrir en Edge/Chrome, pegar el paquete de cambios del agente y descargar el XML + JSON |
| `generar_archimate.py` | Mismo motor en Python (intérprete de código de Copilot Studio); admite `--cambios` |
| `paquete_cambios_ejemplo.json` | Ejemplo del formato que entrega el agente |
| `modelo_processone.json` | **Fuente de verdad** del modelo ArchiMate v0.9.1 (380 elementos, 704 relaciones, 22 vistas) |
| `ProcessOne_ArchiMate_v0.9.1.xml` | XML generado y validado (importar en Archi) |
| `reglas/relaciones_archimate_3_2.json` | Tabla de relaciones permitidas ArchiMate 3.2 (tomada de Archi, archimatetool/archi) |
| `xsd/` | Esquemas oficiales de The Open Group para validar el XML |
| `openapi_fachada_onbase_tmf667.yaml` | Contrato OpenAPI 3.0 borrador de la fachada REST alineada a TMF667 |

## Uso sin instalar nada
1. Doble clic en `Generador_ArchiMate_ProcessOne.html`.
2. Pegar el paquete de cambios → **Aplicar cambios** → **Validar y generar**.
3. **Descargar XML** (para Archi) y **Descargar modelo JSON** (para la próxima sesión).

## Uso con Python (intérprete de código)
```bash
python generar_archimate.py modelo_processone.json --cambios paquete.json -o ProcessOne_ArchiMate.xml --guardar-modelo modelo_processone.json
```
Ambos generadores producen el mismo XML (verificado byte a byte) y lo validan contra la tabla de relaciones ArchiMate 3.2.

Archi: **File → Import → Open Exchange XML Model…** → luego **Save As** `.archimate`.

## Editar el modelo
Ver `K03_guia_archimate_modelo_json.md` (esquema, patrones, errores frecuentes, relaciones permitidas).
