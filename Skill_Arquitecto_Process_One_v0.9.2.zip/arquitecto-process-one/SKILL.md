---
name: arquitecto-process-one
description: Skill de arquitectura empresarial para el proyecto Process One (análisis documental con IA multiagente sobre OnBase y Azure/Microsoft Foundry). Úsala para adaptar el ADD al formato corporativo, analizar documentación de APIs de OnBase, diseñar la fachada REST alineada a TMF667 Document Management, definir datos/consultas/consumos y mantener el modelo ArchiMate (JSON → XML para Archi) con validación automática.
version: 0.9.2
---

# Skill: Arquitecto Process One

## Propósito
Dar a un agente de IA (Copilot Studio con modelos OpenAI u otro) el contexto completo del proyecto y un método repetible para llevar el ADD v0.9.1 a su versión 1.0 con datos reales, sin inventar información confidencial y manteniendo la coherencia entre documento, contratos de API y modelo ArchiMate.

## Estructura
```
arquitecto-process-one/
├── SKILL.md                         ← este archivo (definición de la skill)
├── copilot_studio/
│   ├── 01_instrucciones_agente.md   ← pegar en "Instrucciones" (< 8.000 caracteres)
│   ├── 02_guia_configuracion_copilot_studio.md
│   └── 03_pruebas_y_frases_de_inicio.md
├── conocimiento/                    ← subir como conocimiento del agente
│   ├── K01_contexto_process_one.md
│   ├── K02_guia_adaptacion_ADD.md
│   ├── K03_guia_archimate_modelo_json.md
│   ├── K04_tmf667_fachada_onbase.md
│   ├── K05_definicion_datos_consultas_consumos.md
│   ├── K06_checklist_levantamiento_datos.md
│   └── K07_plantillas_de_salida.md
├── toolkit/                         ← herramientas (sin instalación: HTML; en la nube: intérprete de código)
│   ├── Generador_ArchiMate_ProcessOne.html  ← doble clic en Edge/Chrome: paquete de cambios → XML
│   ├── generar_archimate.py         ← mismo motor para el intérprete de código de Copilot Studio
│   ├── paquete_cambios_ejemplo.json
│   ├── modelo_processone.json
│   ├── ProcessOne_ArchiMate_v0.9.1.xml
│   ├── openapi_fachada_onbase_tmf667.yaml
│   ├── reglas/relaciones_archimate_3_2.json
│   ├── xsd/
│   └── LEEME.md
└── referencia/
    └── ADD_Process_One_v0.9.1.docx  ← subir también como conocimiento
```

## Flujos que cubre
| Flujo | Disparador | Entradas | Salidas |
|---|---|---|---|
| A. Adaptar ADD | Plantilla corporativa | Plantilla + ADD v0.9.1 | Matriz de correspondencia, secciones redactadas, pendientes |
| B. Analizar APIs OnBase | WSDL/manuales | Documentación OnBase | Catálogo de operaciones, presupuesto de llamadas, cambios §6.3/§6.4 |
| C. Fachada TMF667 | Especificación TMF667 | Spec oficial + K04 | OpenAPI actualizado, mapeo de atributos, ADR-16/17 |
| D. ArchiMate | Cualquier cambio de arquitectura | modelo_processone.json | Paquete de cambios JSON → XML validado (agente con intérprete de código o generador HTML) |
| E. Datos y consumos | Definición de datos/consultas | K05 + documentación real | Diccionario, DDL, catálogo de consumos, consultas de ejemplo |

## Reglas no negociables
1. No inventar datos confidenciales; usar `{{Dato}}` y registrarlo en pendientes (K06).
2. Nunca escribir secretos; referenciar Key Vault.
3. Citar la fuente de cada dato real.
4. El agente entrega paquetes de cambios; el XML lo produce el generador (HTML o intérprete de código), nunca a mano.
5. Toda relación ArchiMate se valida contra la tabla 3.2.
6. Respetar ADR vigentes; los cambios de decisión se registran como ADR nuevos.

## Mantenimiento de la skill
- Tras cada sesión productiva, volver a subir al conocimiento: `modelo_processone.json`, el ADD vigente y cualquier K-archivo actualizado.
- Subir la versión de la skill (campo `version`) junto con la del ADD.
