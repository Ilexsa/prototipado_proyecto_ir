# K03 – Guía ArchiMate: modelo JSON → XML para Archi

## 1. Principio de trabajo
- **Fuente de verdad**: `modelo_processone.json`. Nunca se edita ni se escribe el XML a mano.
- **Entregable del agente**: un **paquete de cambios JSON** (§8), pequeño y verificable, en lugar del modelo o del XML completos.
- **Generadores (mismo motor, mismo XML byte a byte)**:
  - `Generador_ArchiMate_ProcessOne.html`: se abre con doble clic en Edge/Chrome; no requiere instalar nada ni conexión. Aplica el paquete, valida, previsualiza y descarga el XML y el JSON actualizado.
  - `generar_archimate.py`: para el intérprete de código de Copilot Studio (o cualquier equipo con Python).
- **Importación en Archi**: `File > Import > Open Exchange XML Model…`. Con `File > Open` aparece el error *"Package with uri 'http://www.opengroup.org/xsd/archimate/3.0/' not found"* (no es un error del archivo). Luego `File > Save As` → `.archimate`.
- Validaciones automáticas: tipos, relaciones contra la tabla ArchiMate 3.2, referencias, solapamientos y cruces de líneas, XSD oficial.

## 2. Esquema del JSON
```json
{
  "meta": {"id": "processone", "version": "0.9.1", "name": "...", "documentation": "..."},
  "elements": [
    {"id": "ac_ing", "type": "ApplicationComponent", "name": "API de Ingesta",
     "doc": "texto opcional", "props": {"ID": "C-04", "Tecnologia": ".NET 8 en Container Apps"}}
  ],
  "relationships": [
    {"type": "Serving", "source": "ai_rest", "target": "ac_ing"},
    {"type": "Access", "source": "ap_i6", "target": "do_raw", "accessType": "Write"},
    {"type": "Association", "source": "do_doc", "target": "do_area", "name": "pertenece a", "directed": true},
    {"type": "Triggering", "source": "jt6", "target": "t7", "name": "Sí"}
  ],
  "views": [
    {"id": "v05", "name": "05 TO-BE ...", "doc": "...", "viewpoint": "Business Process Cooperation",
     "cw": 175, "rh": 105,
     "nodes": [
       {"ref": "t1", "at": [1, 1]},
       {"ref": "rol_an", "as": "rol_an@2", "at": [5.5, 0]},
       {"ref": "loc_az", "children": [ {"ref": "grp_vh", "children": [ {"ref": "n_vpngw", "at": [3.3, 1.2]} ]} ]}
     ],
     "connections": [
       {"type": "Assignment", "source": "rol_an@2", "target": "t4"},
       {"type": "Triggering", "source": "jt6", "target": "t6", "name": "No: observaciones / ajustes", "bends": [[6, 3.6], [7, 3.6]]}
     ]}
  ]
}
```
Reglas del esquema:
- `id` de elemento: minúsculas, sin espacios (`ac_`, `ag`, `do_`, `bo_`, `bp_`/`t`, `rol_`, `n_`, `s_`, `ts_`, `cn_`, `p_`, `loc_`, `grp_`, `wp`, `dl_`, `pl_`, `gap_`, `rf`, `rnf`, `pa`, `rs`, `g`, `o`, `dn`, `as_`, `ai_`, `ap_`, `aev_`, `j`).
- `accessType`: `Read`, `Write`, `ReadWrite`, `Access`.
- En vistas, cada hoja lleva `at: [columna, fila]` (unidades de grilla; `cw` y `rh` son el ancho/alto de celda en px). Se permiten decimales (1.5).
- Contenedores (`children`) no llevan `at`: su caja se calcula de los hijos. Anidar implica relación (agregación/composición) que **debe existir** en `relationships` aunque no se dibuje.
- Un elemento puede aparecer varias veces en una vista con alias `as` (`rol_an@2`). Las conexiones usan el alias.
- `connections` solo dibujan relaciones que existen en `relationships`; si hay dos del mismo tipo entre los mismos elementos, indicar `name`.
- `bends`: puntos de quiebre en coordenadas de grilla para rodear elementos.

## 3. Procedimiento para cualquier cambio
1. Listar el cambio: elementos (id, tipo, nombre, props), relaciones (tipo, origen, destino, nombre), vistas afectadas.
2. Verificar cada relación en el Anexo K03-A. Si no está permitida, buscar la correcta (ver §5).
3. Ubicar en grilla: flujo principal en una fila; actores/roles arriba; servicios de aplicación y objetos de datos abajo; dejar ≥ 1 columna libre entre cajas conectadas en diagonal; usar filas intermedias (1.5, 2.2) para no cruzar cajas.
4. Entregar el **paquete de cambios** (§8) en un único bloque ```json.
5. Generar: HTML (pegar → Aplicar cambios → Validar y generar → Descargar XML y JSON) o intérprete de código (`python generar_archimate.py modelo_processone.json --cambios paquete.json -o ProcessOne_ArchiMate.xml --guardar-modelo modelo_processone.json`).
6. Si aparece `ERROR`: corregir el paquete y entregarlo completo otra vez. Si aparece `AVISO` de cruce: `mover_nodo` o agregar `bends`.
7. Importar en Archi (File > Import > Open Exchange XML Model) y guardar como `.archimate`. Subir el JSON actualizado al conocimiento del agente.

## 4. Patrones de modelado usados en Process One
| Necesidad | Patrón ArchiMate |
|---|---|
| Diagrama de secuencia | Proceso de aplicación con subprocesos + Triggering + OrJunction + ApplicationEvent inicio/fin + Access a DataObject + Assignment del componente |
| Máquina de estados | BusinessEvent por estado, disparado por/hacia BusinessProcess |
| Swimlanes AS-IS/TO-BE | BusinessProcess por paso + Assignment desde BusinessRole (roles duplicados con alias cerca de cada paso) + propiedad `Estado` = AS-IS / TO-BE / AS-IS y TO-BE |
| Apoyo de IA a un paso | ApplicationService —Serving→ BusinessProcess |
| API | ApplicationInterface compuesta por el ApplicationComponent; Interface —Serving→ consumidor |
| Integración de datos | Flow entre ApplicationComponent (con nombre del dato) |
| Red | Location → Grouping (VNet) → Node/Device; CommunicationNetwork y Path con Association; Node —Realization→ TechnologyService —Serving→ ApplicationComponent |
| Modelos de IA | SystemSoftware compuesto por el Node de Foundry; SystemSoftware —Serving→ ApplicationComponent |
| Despliegue | Node —Assignment→ Artifact —Realization→ ApplicationComponent |
| Modelo de datos | DataObject con Composition/Aggregation/Association dirigida con nombre; DataObject —Realization→ BusinessObject |
| Trazabilidad | ApplicationComponent —Realization→ Requirement |
| Migración | WorkPackage —Realization→ Deliverable —Realization→ Plateau; Plateau —Triggering→ Plateau; Gap —Association→ Plateau |

## 5. Errores frecuentes (relaciones NO permitidas en ArchiMate 3.2) y corrección
| Intento inválido | Correcto |
|---|---|
| Node —Composition→ ApplicationComponent | Node —Assignment→ Artifact —Realization→ ApplicationComponent, o Node —Serving→ ApplicationComponent |
| CommunicationNetwork —Aggregation→ Node | CommunicationNetwork —Association→ Node |
| Requirement —Realization→ ApplicationComponent | ApplicationComponent —Realization→ Requirement (la dirección va del que realiza al requerimiento) |
| Goal —Realization→ Requirement | Requirement —Realization→ Goal (u Outcome) |
| BusinessObject —Realization→ DataObject | DataObject —Realization→ BusinessObject |
| DataObject —Access→ ApplicationComponent | ApplicationComponent/Process —Access→ DataObject (el acceso sale del comportamiento o estructura activa) |
| DataObject —Flow→ DataObject | Association dirigida con nombre, o Flow entre los componentes/procesos que los manejan |
| Specialization entre tipos distintos | Solo entre elementos del mismo tipo |

Buenas prácticas (válidas, pero preferidas en este modelo):
- Rol → proceso: usar **Assignment** (quién ejecuta), no Serving.
- Componente → objeto de negocio: modelar el DataObject y su Realization del BusinessObject; el componente accede al DataObject.
- Relación desde una Grouping: aplica a todos sus miembros; úsala para evitar decenas de líneas repetidas.

## 6. Vistas actuales del modelo v0.9.1 (22)
01 Motivación · 02 Principios, restricciones y requerimientos · 03 Mapa de capacidades · 04 AS-IS · 05 TO-BE · 06 Arquitectura de solución · 07 Cooperación de aplicaciones (incluye SGP) · 08 Ingesta con cuota · 09 Pipeline skillset · 10 Multiagente · 11 Análisis documental · 12 Consulta conversacional · 13 Estructura de información · 13b Solicitud, borradores y aprobaciones · 14 Red y conectividad · 15 Despliegue · 16 Uso de tecnología · 17 Paquetes de trabajo · 18 Entregables y plateaus · 19 Brechas · 20 Trazabilidad RF/RNF · 21 Carga controlada a OnBase.

## 7. Cambios esperados próximos (sugeridos)
- Reemplazar la interfaz `ai_rest` ("Fachada REST /onbase/v1") por "API TMF667 Document Management (fachada OnBase)" y agregar ApplicationInterface por operación si se requiere detalle.
- Agregar DataObject "Document (TMF667)" y "Attachment (TMF667)" con Realization hacia `bo_doc`/`bo_adj`, y Association con `do_doc`/`do_adj` ("se expone como").
- Reemplazar marcadores `{{…}}` en nombres de nodos de red (vista 14) con IPs/rangos reales solo si la clasificación del modelo lo permite; si no, conservar el marcador y guardar los datos en propiedades.
- Nueva vista "22 Consultas y consumos" (consumidores → interfaces → datos) basada en K05.

## 8. Paquete de cambios (formato que entrega el agente)
```json
{
  "version": "0.9.2",
  "descripcion": "Qué cambia y por qué (una línea)",
  "operaciones": [ { "op": "…", … } ]
}
```
Las operaciones se aplican en orden. Si alguna falla, **no se aplica ninguna** y se muestra el motivo.

| op | Campos | Efecto |
|---|---|---|
| `agregar_elemento` | `elemento` {id, type, name, doc?, props?} | Crea el elemento (error si el id existe) |
| `modificar_elemento` | `id`, `cambios` {name?, doc?, type?, props?} | Actualiza; en `props`, un valor `null` borra la propiedad |
| `eliminar_elemento` | `id` | Elimina el elemento, sus relaciones y sus nodos/conexiones en todas las vistas |
| `agregar_relacion` | `relacion` {type, source, target, name?, accessType?, directed?} | Crea la relación (se ignora si ya existe idéntica) |
| `eliminar_relacion` | type, source, target, name? | Elimina la relación y sus conexiones en vistas |
| `agregar_vista` / `reemplazar_vista` | `vista` (objeto completo, ver §2) | Crea o reemplaza la vista por id |
| `eliminar_vista` | `id` | Elimina la vista |
| `agregar_nodo` | `vista`, `nodo` {ref, at, as?}, `dentro_de`? | Agrega un nodo (dentro de un contenedor si se indica) |
| `mover_nodo` | `vista`, `nodo` (id o alias), `at` | Cambia la posición |
| `quitar_nodo` | `vista`, `nodo` | Quita el nodo y sus conexiones de esa vista (el elemento sigue en el modelo) |
| `agregar_conexion` | `vista`, `conexion` {type, source, target, name?, bends?} | Dibuja una relación existente |
| `quitar_conexion` | `vista`, type, source, target | Deja de dibujarla (la relación sigue en el modelo) |
| `modificar_meta` | `cambios` {name?, documentation?, version?} | Metadatos del modelo |

Reglas: primero `agregar_elemento`, luego `agregar_relacion`, al final nodos y conexiones. Toda conexión exige que la relación exista. Los ids nuevos siguen los prefijos de §2.

Ejemplo real (interfaz TMF667 en la vista 07):
```json
{
 "version": "0.9.2",
 "descripcion": "Ejemplo: interfaz TMF667 en la vista 07",
 "operaciones": [
  {
   "op": "agregar_elemento",
   "elemento": {
    "id": "ai_tmf",
    "type": "ApplicationInterface",
    "name": "API TMF667 Document Management (fachada OnBase)",
    "props": {
     "Estandar": "TM Forum TMF667 v{{x}}"
    }
   }
  },
  {
   "op": "agregar_relacion",
   "relacion": {
    "type": "Composition",
    "source": "ac_gw",
    "target": "ai_tmf"
   }
  },
  {
   "op": "agregar_relacion",
   "relacion": {
    "type": "Serving",
    "source": "ai_tmf",
    "target": "ac_ing"
   }
  },
  {
   "op": "agregar_nodo",
   "vista": "v07",
   "nodo": {
    "ref": "ai_tmf",
    "at": [
     3,
     -1
    ]
   }
  },
  {
   "op": "agregar_conexion",
   "vista": "v07",
   "conexion": {
    "type": "Composition",
    "source": "ac_gw",
    "target": "ai_tmf"
   }
  },
  {
   "op": "agregar_conexion",
   "vista": "v07",
   "conexion": {
    "type": "Serving",
    "source": "ai_tmf",
    "target": "ac_ing"
   }
  }
 ]
}
```

## Anexo K03-A. Relaciones permitidas (ArchiMate 3.2) entre los tipos más usados
Formato: ORIGEN → DESTINO: relaciones permitidas. Abreviaturas: Acc=Access, Comp=Composition, Flow, Agg=Aggregation, Asig=Assignment, Infl=Influence, Asoc=Association, Real=Realization, Esp=Specialization, Disp=Triggering, Serv=Serving. La tabla completa (62 conceptos) está en toolkit/reglas/relaciones_archimate_3_2.json y el generador la aplica automáticamente.

### BusinessActor
BusinessActor: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; BusinessRole: Flow, Asig, Asoc, Disp, Serv; BusinessProcess: Flow, Asig, Asoc, Disp, Serv; BusinessEvent: Flow, Asig, Asoc, Disp, Serv; BusinessService: Flow, Asig, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Asig, Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asig, Asoc; Deliverable: Asoc; ImplementationEvent: Asig, Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### BusinessRole
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; BusinessProcess: Flow, Asig, Asoc, Disp, Serv; BusinessEvent: Flow, Asig, Asoc, Disp, Serv; BusinessService: Flow, Asig, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Asig, Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asig, Asoc; Deliverable: Asoc; ImplementationEvent: Asig, Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### BusinessProcess
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; BusinessEvent: Flow, Asoc, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### BusinessEvent
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Disp, Serv; BusinessEvent: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; BusinessService: Flow, Asoc, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### BusinessService
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Disp, Serv; BusinessEvent: Flow, Asoc, Disp, Serv; BusinessService: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### BusinessObject
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Comp, Agg, Asoc, Esp; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### ApplicationComponent
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asoc, Real, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; ApplicationInterface: Comp, Flow, Agg, Asoc, Real, Disp, Serv; ApplicationProcess: Flow, Asig, Asoc, Real, Disp, Serv; ApplicationFunction: Flow, Asig, Asoc, Real, Disp, Serv; ApplicationEvent: Flow, Asig, Asoc, Real, Disp, Serv; ApplicationService: Flow, Asig, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### ApplicationInterface
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Disp, Serv; BusinessEvent: Flow, Asoc, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asig, Asoc, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### ApplicationProcess
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asoc, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; ApplicationFunction: Comp, Flow, Agg, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### ApplicationFunction
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asoc, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Comp, Flow, Agg, Asoc, Disp, Serv; ApplicationFunction: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### ApplicationEvent
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Disp, Serv; BusinessEvent: Flow, Asoc, Real, Disp, Serv; BusinessService: Flow, Asoc, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; ApplicationService: Flow, Asoc, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### ApplicationService
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Disp, Serv; BusinessEvent: Flow, Asoc, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Flow, Asoc, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### DataObject
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc, Real; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Comp, Agg, Asoc, Esp; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Node
BusinessActor: Flow, Asig, Asoc, Disp, Serv; BusinessRole: Flow, Asig, Asoc, Disp, Serv; BusinessProcess: Flow, Asig, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asig, Asoc, Real, Disp, Serv; BusinessService: Flow, Asig, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Real, Disp, Serv; ApplicationInterface: Flow, Asoc, Real, Disp, Serv; ApplicationProcess: Flow, Asoc, Real, Disp, Serv; ApplicationFunction: Flow, Asoc, Real, Disp, Serv; ApplicationEvent: Flow, Asoc, Real, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Comp, Flow, Agg, Asig, Asoc, Esp, Disp, Serv; Device: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; SystemSoftware: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; TechnologyService: Flow, Asig, Asoc, Real, Disp, Serv; Artifact: Acc, Asig, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Asig, Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asig, Asoc; Deliverable: Asoc; ImplementationEvent: Asig, Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Device
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asoc, Real, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Real, Disp, Serv; ApplicationInterface: Flow, Asoc, Real, Disp, Serv; ApplicationProcess: Flow, Asoc, Real, Disp, Serv; ApplicationFunction: Flow, Asoc, Real, Disp, Serv; ApplicationEvent: Flow, Asoc, Real, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; SystemSoftware: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; TechnologyService: Flow, Asig, Asoc, Real, Disp, Serv; Artifact: Acc, Asig, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### SystemSoftware
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asoc, Real, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Real, Disp, Serv; ApplicationInterface: Flow, Asoc, Real, Disp, Serv; ApplicationProcess: Flow, Asoc, Real, Disp, Serv; ApplicationFunction: Flow, Asoc, Real, Disp, Serv; ApplicationEvent: Flow, Asoc, Real, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; TechnologyService: Flow, Asig, Asoc, Real, Disp, Serv; Artifact: Acc, Asig, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### TechnologyService
BusinessActor: Flow, Asoc, Disp, Serv; BusinessRole: Flow, Asoc, Disp, Serv; BusinessProcess: Flow, Asoc, Disp, Serv; BusinessEvent: Flow, Asoc, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Disp, Serv; ApplicationInterface: Flow, Asoc, Disp, Serv; ApplicationProcess: Flow, Asoc, Disp, Serv; ApplicationFunction: Flow, Asoc, Disp, Serv; ApplicationEvent: Flow, Asoc, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Disp, Serv; Device: Flow, Asoc, Disp, Serv; SystemSoftware: Flow, Asoc, Disp, Serv; TechnologyService: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; Artifact: Acc, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Flow, Asoc, Disp, Serv; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Artifact
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc, Real; BusinessEvent: Asoc, Real; BusinessService: Asoc, Real; BusinessObject: Asoc, Real; ApplicationComponent: Asoc, Real; ApplicationInterface: Asoc, Real; ApplicationProcess: Asoc, Real; ApplicationFunction: Asoc, Real; ApplicationEvent: Asoc, Real; ApplicationService: Asoc, Real; DataObject: Asoc, Real; Node: Asoc; Device: Asoc; SystemSoftware: Asoc, Real; TechnologyService: Asoc, Real; Artifact: Comp, Agg, Asoc, Real, Esp; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### CommunicationNetwork
BusinessActor: Flow, Asoc, Real, Disp, Serv; BusinessRole: Flow, Asoc, Real, Disp, Serv; BusinessProcess: Flow, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asoc, Real, Disp, Serv; BusinessService: Flow, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Real, Disp, Serv; ApplicationInterface: Flow, Asoc, Real, Disp, Serv; ApplicationProcess: Flow, Asoc, Real, Disp, Serv; ApplicationFunction: Flow, Asoc, Real, Disp, Serv; ApplicationEvent: Flow, Asoc, Real, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Asoc, Real, Disp, Serv; Device: Flow, Agg, Asoc, Real, Disp, Serv; SystemSoftware: Flow, Agg, Asig, Asoc, Real, Disp, Serv; TechnologyService: Flow, Asig, Asoc, Real, Disp, Serv; Artifact: Acc, Asig, Asoc; CommunicationNetwork: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; Path: Flow, Asoc, Real, Disp, Serv; Stakeholder: Infl, Asoc, Real; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Path
BusinessActor: Flow, Asig, Asoc, Disp, Serv; BusinessRole: Flow, Asig, Asoc, Disp, Serv; BusinessProcess: Flow, Asig, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asig, Asoc, Real, Disp, Serv; BusinessService: Flow, Asig, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc; ApplicationComponent: Flow, Asoc, Real, Disp, Serv; ApplicationInterface: Flow, Asoc, Real, Disp, Serv; ApplicationProcess: Flow, Asoc, Real, Disp, Serv; ApplicationFunction: Flow, Asoc, Real, Disp, Serv; ApplicationEvent: Flow, Asoc, Real, Disp, Serv; ApplicationService: Flow, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc; Node: Flow, Agg, Asig, Asoc, Disp, Serv; Device: Flow, Agg, Asig, Asoc, Real, Disp, Serv; SystemSoftware: Flow, Agg, Asig, Asoc, Real, Disp, Serv; TechnologyService: Flow, Asig, Asoc, Real, Disp, Serv; Artifact: Acc, Asig, Asoc; CommunicationNetwork: Flow, Asoc, Disp, Serv; Path: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; Stakeholder: Asig, Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asig, Asoc; Deliverable: Asoc; ImplementationEvent: Asig, Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Flow, Asoc, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Stakeholder
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Comp, Agg, Infl, Asoc, Esp; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc; Outcome: Infl, Asoc; Principle: Infl, Asoc; Requirement: Infl, Asoc; Constraint: Infl, Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Driver
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Comp, Agg, Infl, Asoc, Esp; Assessment: Infl, Asoc; Goal: Infl, Asoc; Outcome: Infl, Asoc; Principle: Infl, Asoc; Requirement: Infl, Asoc; Constraint: Infl, Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Assessment
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Comp, Agg, Infl, Asoc, Esp; Goal: Infl, Asoc; Outcome: Infl, Asoc; Principle: Infl, Asoc; Requirement: Infl, Asoc; Constraint: Infl, Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Goal
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Comp, Agg, Infl, Asoc, Esp; Outcome: Infl, Asoc; Principle: Infl, Asoc; Requirement: Infl, Asoc; Constraint: Infl, Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Outcome
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Comp, Agg, Infl, Asoc, Esp; Principle: Infl, Asoc; Requirement: Infl, Asoc; Constraint: Infl, Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Principle
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Comp, Agg, Infl, Asoc, Esp; Requirement: Infl, Asoc; Constraint: Infl, Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Requirement
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Comp, Agg, Infl, Asoc, Esp; Constraint: Comp, Agg, Infl, Asoc, Esp; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Constraint
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Comp, Agg, Infl, Asoc, Esp; Constraint: Comp, Agg, Infl, Asoc, Esp; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Capability
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; Resource: Flow, Asoc, Disp, Serv; CourseOfAction: Flow, Asoc, Real, Disp, Serv; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Resource
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Flow, Asig, Asoc, Disp, Serv; Resource: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; CourseOfAction: Flow, Asoc, Real, Disp, Serv; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### CourseOfAction
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Flow, Asoc, Disp, Serv; Resource: Flow, Asoc, Disp, Serv; CourseOfAction: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Asoc; Grouping: Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp, Serv; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### WorkPackage
BusinessActor: Asoc, Real; BusinessRole: Asoc, Real; BusinessProcess: Asoc, Real; BusinessEvent: Asoc, Real; BusinessService: Asoc, Real; BusinessObject: Asoc, Real; ApplicationComponent: Asoc, Real; ApplicationInterface: Asoc, Real; ApplicationProcess: Asoc, Real; ApplicationFunction: Asoc, Real; ApplicationEvent: Asoc, Real; ApplicationService: Asoc, Real; DataObject: Asoc, Real; Node: Asoc, Real; Device: Asoc, Real; SystemSoftware: Asoc, Real; TechnologyService: Asoc, Real; Artifact: Asoc, Real; CommunicationNetwork: Asoc, Real; Path: Asoc, Real; Stakeholder: Infl, Asoc, Real; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Comp, Flow, Agg, Asoc, Esp, Disp; Deliverable: Acc, Asoc, Real; ImplementationEvent: Flow, Asoc, Disp; Plateau: Flow, Asoc, Real, Disp; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Real, Esp, Disp; Location: Asoc, Real; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Deliverable
BusinessActor: Asoc, Real; BusinessRole: Asoc, Real; BusinessProcess: Asoc, Real; BusinessEvent: Asoc, Real; BusinessService: Asoc, Real; BusinessObject: Asoc, Real; ApplicationComponent: Asoc, Real; ApplicationInterface: Asoc, Real; ApplicationProcess: Asoc, Real; ApplicationFunction: Asoc, Real; ApplicationEvent: Asoc, Real; ApplicationService: Asoc, Real; DataObject: Asoc, Real; Node: Asoc, Real; Device: Asoc, Real; SystemSoftware: Asoc, Real; TechnologyService: Asoc, Real; Artifact: Asoc, Real; CommunicationNetwork: Asoc, Real; Path: Asoc, Real; Stakeholder: Infl, Asoc, Real; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Asoc, Real; Resource: Asoc, Real; CourseOfAction: Asoc, Real; WorkPackage: Asoc; Deliverable: Comp, Agg, Asoc, Esp; ImplementationEvent: Asoc; Plateau: Asoc, Real; Gap: Asoc; Grouping: Comp, Agg, Infl, Asoc, Real, Esp; Location: Asoc, Real; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### ImplementationEvent
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Infl, Asoc; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc; Outcome: Infl, Asoc; Principle: Infl, Asoc; Requirement: Infl, Asoc; Constraint: Infl, Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Flow, Asoc, Disp; Deliverable: Acc, Asoc; ImplementationEvent: Comp, Flow, Agg, Asoc, Esp, Disp; Plateau: Flow, Asoc, Disp; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Infl, Asoc, Esp, Disp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Plateau
BusinessActor: Comp, Agg, Asoc, Real; BusinessRole: Comp, Agg, Asoc, Real; BusinessProcess: Comp, Agg, Asoc, Real; BusinessEvent: Comp, Agg, Asoc, Real; BusinessService: Comp, Agg, Asoc, Real; BusinessObject: Comp, Agg, Asoc, Real; ApplicationComponent: Comp, Agg, Asoc, Real; ApplicationInterface: Comp, Agg, Asoc, Real; ApplicationProcess: Comp, Agg, Asoc, Real; ApplicationFunction: Comp, Agg, Asoc, Real; ApplicationEvent: Comp, Agg, Asoc, Real; ApplicationService: Comp, Agg, Asoc, Real; DataObject: Comp, Agg, Asoc, Real; Node: Comp, Agg, Asoc, Real; Device: Comp, Agg, Asoc, Real; SystemSoftware: Comp, Agg, Asoc, Real; TechnologyService: Comp, Agg, Asoc, Real; Artifact: Comp, Agg, Asoc, Real; CommunicationNetwork: Comp, Agg, Asoc, Real; Path: Comp, Agg, Asoc, Real; Stakeholder: Asig, Infl, Asoc, Real; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Comp, Agg, Infl, Asoc, Real; Outcome: Comp, Agg, Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Comp, Agg, Infl, Asoc, Real; Constraint: Comp, Agg, Infl, Asoc, Real; Capability: Comp, Agg, Asoc, Real; Resource: Comp, Agg, Asoc, Real; CourseOfAction: Comp, Agg, Asoc, Real; WorkPackage: Flow, Asoc, Disp; Deliverable: Acc, Asoc; ImplementationEvent: Flow, Asoc, Disp; Plateau: Comp, Flow, Agg, Asoc, Esp, Disp; Gap: Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp; Location: Comp, Agg, Asoc, Real; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Gap
BusinessActor: Asoc; BusinessRole: Asoc; BusinessProcess: Asoc; BusinessEvent: Asoc; BusinessService: Asoc; BusinessObject: Asoc; ApplicationComponent: Asoc; ApplicationInterface: Asoc; ApplicationProcess: Asoc; ApplicationFunction: Asoc; ApplicationEvent: Asoc; ApplicationService: Asoc; DataObject: Asoc; Node: Asoc; Device: Asoc; SystemSoftware: Asoc; TechnologyService: Asoc; Artifact: Asoc; CommunicationNetwork: Asoc; Path: Asoc; Stakeholder: Asoc; Driver: Asoc; Assessment: Asoc; Goal: Asoc; Outcome: Asoc; Principle: Asoc; Requirement: Asoc; Constraint: Asoc; Capability: Asoc; Resource: Asoc; CourseOfAction: Asoc; WorkPackage: Asoc; Deliverable: Asoc; ImplementationEvent: Asoc; Plateau: Asoc; Gap: Comp, Agg, Asoc, Esp; Grouping: Comp, Agg, Asoc, Esp; Location: Asoc; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Grouping
BusinessActor: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; BusinessRole: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; BusinessProcess: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; BusinessEvent: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; BusinessService: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; BusinessObject: Acc, Comp, Agg, Asoc, Real, Esp; ApplicationComponent: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; ApplicationInterface: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; ApplicationProcess: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; ApplicationFunction: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; ApplicationEvent: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; ApplicationService: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; DataObject: Acc, Comp, Agg, Asoc, Real, Esp; Node: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; Device: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; SystemSoftware: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; TechnologyService: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; Artifact: Acc, Comp, Agg, Asig, Asoc, Real, Esp; CommunicationNetwork: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; Path: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; Stakeholder: Comp, Agg, Asig, Infl, Asoc, Real, Esp; Driver: Comp, Agg, Infl, Asoc, Esp; Assessment: Comp, Agg, Infl, Asoc, Esp; Goal: Comp, Agg, Infl, Asoc, Real, Esp; Outcome: Comp, Agg, Infl, Asoc, Real, Esp; Principle: Comp, Agg, Infl, Asoc, Real, Esp; Requirement: Comp, Agg, Infl, Asoc, Real, Esp; Constraint: Comp, Agg, Infl, Asoc, Real, Esp; Capability: Comp, Flow, Agg, Asig, Asoc, Real, Esp, Disp, Serv; Resource: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; CourseOfAction: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; WorkPackage: Comp, Flow, Agg, Asig, Asoc, Esp, Disp; Deliverable: Acc, Comp, Agg, Asoc, Real, Esp; ImplementationEvent: Comp, Flow, Agg, Asig, Asoc, Esp, Disp; Plateau: Comp, Flow, Agg, Asoc, Real, Esp, Disp; Gap: Comp, Agg, Asoc, Esp; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Comp, Flow, Agg, Asoc, Real, Esp, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Location
BusinessActor: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; BusinessRole: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; BusinessProcess: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; BusinessEvent: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; BusinessService: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; BusinessObject: Acc, Comp, Agg, Asoc; ApplicationComponent: Comp, Flow, Agg, Asoc, Real, Disp, Serv; ApplicationInterface: Comp, Flow, Agg, Asoc, Real, Disp, Serv; ApplicationProcess: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; ApplicationFunction: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; ApplicationEvent: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; ApplicationService: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; DataObject: Acc, Comp, Agg, Asoc; Node: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; Device: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; SystemSoftware: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; TechnologyService: Comp, Flow, Agg, Asig, Asoc, Real, Disp, Serv; Artifact: Acc, Comp, Agg, Asig, Asoc; CommunicationNetwork: Comp, Flow, Agg, Asoc, Disp, Serv; Path: Comp, Flow, Agg, Asoc, Real, Disp, Serv; Stakeholder: Comp, Agg, Asig, Infl, Asoc, Real; Driver: Comp, Agg, Infl, Asoc; Assessment: Comp, Agg, Infl, Asoc; Goal: Comp, Agg, Infl, Asoc, Real; Outcome: Comp, Agg, Infl, Asoc, Real; Principle: Comp, Agg, Infl, Asoc, Real; Requirement: Comp, Agg, Infl, Asoc, Real; Constraint: Comp, Agg, Infl, Asoc, Real; Capability: Comp, Agg, Asoc, Real; Resource: Comp, Agg, Asoc, Real; CourseOfAction: Comp, Agg, Asoc, Real; WorkPackage: Comp, Agg, Asig, Asoc; Deliverable: Comp, Agg, Asoc; ImplementationEvent: Comp, Agg, Asig, Asoc; Plateau: Comp, Agg, Asoc; Gap: Comp, Agg, Asoc; Grouping: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv; Location: Comp, Flow, Agg, Asoc, Esp, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv

### Junction
BusinessActor: Flow, Asig, Asoc, Real, Disp, Serv; BusinessRole: Flow, Asig, Asoc, Real, Disp, Serv; BusinessProcess: Flow, Asig, Asoc, Real, Disp, Serv; BusinessEvent: Flow, Asig, Asoc, Real, Disp, Serv; BusinessService: Flow, Asig, Asoc, Real, Disp, Serv; BusinessObject: Acc, Asoc, Real; ApplicationComponent: Flow, Asoc, Real, Disp, Serv; ApplicationInterface: Flow, Asoc, Real, Disp, Serv; ApplicationProcess: Flow, Asig, Asoc, Real, Disp, Serv; ApplicationFunction: Flow, Asig, Asoc, Real, Disp, Serv; ApplicationEvent: Flow, Asig, Asoc, Real, Disp, Serv; ApplicationService: Flow, Asig, Asoc, Real, Disp, Serv; DataObject: Acc, Asoc, Real; Node: Flow, Asig, Asoc, Real, Disp, Serv; Device: Flow, Asig, Asoc, Real, Disp, Serv; SystemSoftware: Flow, Asig, Asoc, Real, Disp, Serv; TechnologyService: Flow, Asig, Asoc, Real, Disp, Serv; Artifact: Acc, Asig, Asoc, Real; CommunicationNetwork: Flow, Asoc, Real, Disp, Serv; Path: Flow, Asoc, Real, Disp, Serv; Stakeholder: Asig, Infl, Asoc, Real; Driver: Infl, Asoc; Assessment: Infl, Asoc; Goal: Infl, Asoc, Real; Outcome: Infl, Asoc, Real; Principle: Infl, Asoc, Real; Requirement: Infl, Asoc, Real; Constraint: Infl, Asoc, Real; Capability: Flow, Asig, Asoc, Real, Disp, Serv; Resource: Flow, Asoc, Real, Disp, Serv; CourseOfAction: Flow, Asoc, Real, Disp, Serv; WorkPackage: Flow, Asig, Asoc, Disp; Deliverable: Acc, Asoc, Real; ImplementationEvent: Flow, Asig, Asoc, Disp; Plateau: Flow, Asoc, Real, Disp; Gap: Asoc; Grouping: Acc, Flow, Asig, Infl, Asoc, Real, Disp, Serv; Location: Flow, Asoc, Real, Disp, Serv; Junction: Acc, Comp, Flow, Agg, Asig, Infl, Asoc, Real, Esp, Disp, Serv
