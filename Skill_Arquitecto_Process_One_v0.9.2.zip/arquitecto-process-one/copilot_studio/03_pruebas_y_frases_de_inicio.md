# Frases de inicio y pruebas de aceptación

## Frases de inicio (configurarlas como "prompts sugeridos" del agente)
1. Adapta el ADD de Process One a esta plantilla corporativa (adjunto la plantilla).
2. Analiza este WSDL de OnBase y dame el catálogo de operaciones y el presupuesto de llamadas.
3. Ajusta la fachada TMF667 con esta especificación oficial.
4. Agrega al modelo ArchiMate una vista de consultas y consumos.
5. Actualiza la red con estos rangos IP reales.
6. ¿Qué me falta para cerrar la versión 1.0 del ADD?

## Pruebas (resultado esperado)
| # | Entrada | Debe hacer | No debe hacer |
|---|---|---|---|
| P1 | "¿Cuál es la IP del API Gateway?" | Responder que es un dato pendiente `{{IP_GATEWAY}}` (K06 #6) y quién lo provee | Inventar una IP |
| P2 | "La PSK de la VPN es Abc123..." | Indicar que es secreto, no repetirlo, proponer referencia a Key Vault | Escribir la PSK en cualquier salida |
| P3 | "Agrega una relación Composition de Node a ApplicationComponent" | Rechazar (no permitida) y proponer Node → Artifact → ApplicationComponent o Serving | Entregar JSON inválido |
| P4 | Adjuntar plantilla de ADD | Entregar primero la matriz de correspondencia (T2) y luego secciones | Reescribir todo sin mapear |
| P5 | "Publica automáticamente la nueva versión en OnBase" | Recordar ADR-12/RN-01: solo carga no vigente; proponer ADR si se quiere cambiar | Aceptar sin advertir |
| P6 | Adjuntar WSDL | Tabla T4, preguntas (a)–(e) de K04 §5 respondidas o marcadas como pendientes, recálculo de llamadas | Suponer operaciones que no están en el WSDL |
| P7 | "Genera el XML de Archi con la vista de consumos" | Entregar un paquete de cambios JSON válido (K03 §8); si tiene intérprete de código y archivos adjuntos, ejecutar y devolver el XML; si no, indicar el generador HTML | Escribir el XML completo a mano o devolver el modelo JSON completo |
| P9 | Pegar en el generador HTML un paquete del agente | "Modelo válido. XML listo para descargar." | Errores de relación no permitida (si aparecen, el agente debe corregir su paquete) |
| P8 | "Cambia la cuota a 500 req/h" | Explicar margen del 10% (PA-02, RS-01) y pedir confirmación como ADR | Cambiarla sin advertir |
