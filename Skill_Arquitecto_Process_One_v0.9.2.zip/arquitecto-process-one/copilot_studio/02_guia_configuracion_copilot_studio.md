# Guía de configuración – Agente "Arquitecto Process One" en Copilot Studio

Tiempo estimado: 30–45 minutos. Requiere licencia/capacidad de Copilot Studio y un entorno de Power Platform autorizado por la organización.

## 1. Crear el agente
1. Entrar a Copilot Studio con la cuenta corporativa y elegir el **entorno** autorizado (idealmente uno personal o de Arquitectura, no el de producción de Process One).
2. **Crear → Nuevo agente → Configurar** (saltar la creación conversacional).
3. **Nombre:** `Arquitecto Process One`. **Descripción:** `Asistente de arquitectura para adaptar el ADD de Process One al formato corporativo, analizar APIs de OnBase/TMF667 y mantener el modelo ArchiMate.`
4. **Instrucciones:** pegar el contenido completo de `01_instrucciones_agente.md` (≈ 5.700 caracteres; el límite de Copilot Studio es 8.000).
5. **Idioma principal:** Español.

## 2. Modelo
En la configuración del agente (sección de modelo / IA generativa) seleccionar el modelo **OpenAI** de mayor capacidad disponible en el tenant (por ejemplo, la familia GPT-5 o GPT-4.1). Mantener **orquestación generativa** activada.

## 3. Conocimiento (subir archivos)
Subir como archivos de conocimiento:
| Archivo | Propósito |
|---|---|
| `K01_contexto_process_one.md` | Contexto y decisiones del proyecto |
| `K02_guia_adaptacion_ADD.md` | Cómo adaptar al formato corporativo |
| `K03_guia_archimate_modelo_json.md` | Reglas ArchiMate, esquema JSON, relaciones permitidas |
| `K04_tmf667_fachada_onbase.md` | Diseño TMF667 sobre OnBase |
| `K05_definicion_datos_consultas_consumos.md` | Datos, consultas, consumos, DDL |
| `K06_checklist_levantamiento_datos.md` | Datos a levantar y su clasificación |
| `K07_plantillas_de_salida.md` | Formatos de entrega |
| `ADD_Process_One_v0.9.1.docx` | Documento base |
| `openapi_fachada_onbase_tmf667.yaml` | Contrato borrador de la fachada |
| `modelo_processone.json` | Modelo ArchiMate (fuente de verdad) |
| `paquete_cambios_ejemplo.json` | Ejemplo del formato de paquete de cambios |

Notas:
- Si Copilot Studio no acepta `.md`, `.yaml` o `.json`, cambiar la extensión a `.txt` (el contenido es texto plano).
- Agregar después, a medida que los obtengas: plantilla corporativa de ADD, WSDL/manuales de OnBase, especificación TMF667 oficial (PDF/JSON), políticas de red/seguridad. Los archivos grandes funcionan mejor como **conocimiento** (o en una biblioteca de SharePoint conectada) que como adjuntos del chat.
- Desactivar **búsqueda web** si la política de la organización lo exige; la especificación TMF667 se aporta como archivo.

## 4. Capacidades
- **Intérprete de código (Code interpreter):** activarlo si el tenant lo permite. Con él, el agente ejecuta el generador en la nube de Microsoft (no en tu PC) y te devuelve el XML directamente. Para eso adjunta en el chat: `generar_archimate.py`, `reglas/relaciones_archimate_3_2.json` y `modelo_processone.json`.
- **Carga de archivos por el usuario:** activarla para adjuntar plantillas, WSDL y los archivos anteriores.
- Si el intérprete de código no está disponible: el agente entrega el **paquete de cambios** y el XML se obtiene con `Generador_ArchiMate_ProcessOne.html` (sección 6). No se necesita Python.

## 5. Publicación y acceso
- Canal: **Microsoft Teams** (y/o chat de prueba del portal).
- Compartir solo contigo o con el equipo de Arquitectura. Revisar políticas DLP de Power Platform del entorno.
- No subir secretos (contraseñas, PSK, certificados) ni al conocimiento ni al chat.

## 6. Obtener el XML sin instalar nada
1. Abrir `Generador_ArchiMate_ProcessOne.html` con doble clic (Edge o Chrome). Funciona sin conexión; el modelo no sale del equipo.
2. **Modelo base**: usar el incluido (v0.9.1) o cargar el último `modelo_processone.json` descargado.
3. **Paquete de cambios**: pegar el bloque JSON del agente → **Aplicar cambios**.
4. **Validar y generar** → revisar errores/avisos y la vista previa → **Descargar XML** y **Descargar modelo JSON**.
5. Archi: **File → Import → Open Exchange XML Model…** (no usar File → Open) → **Save As** `.archimate`.
6. Subir el `modelo_processone.json` descargado al conocimiento del agente (reemplazando el anterior).

Alternativa con Python (si algún día lo tienes): `python generar_archimate.py modelo_processone.json --cambios paquete.json -o ProcessOne_ArchiMate.xml --guardar-modelo modelo_processone.json`.

## 7. Ciclo de trabajo recomendado
1. Subir un documento nuevo (p. ej., WSDL de OnBase) → pedir el análisis (flujo B).
2. Pedir los cambios derivados: ADD (secciones), K05 (consumos), modelo ArchiMate (JSON).
3. Obtener el XML: el agente lo entrega (intérprete de código) o pegas su paquete de cambios en el generador HTML.
4. Importar en Archi, revisar la vista y exportar imágenes para el ADD.
5. Volver a subir al conocimiento el `modelo_processone.json` actualizado para que el agente trabaje siempre sobre la última versión.

## 8. Pruebas de aceptación del agente
Ejecutar las pruebas de `03_pruebas_y_frases_de_inicio.md`. Si alguna falla, reforzar la instrucción correspondiente o el archivo de conocimiento.
