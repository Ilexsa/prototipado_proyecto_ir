# Guía de configuración en Copilot Studio

Aplica a **Copilot Studio** (copilotstudio.microsoft.com), no al creador de agentes de la app de Microsoft 365 Copilot. Las opciones de menú pueden variar levemente según la versión de tu tenant.

## 0. Qué vas a construir
| Opción | Cuándo usarla | Agentes |
|---|---|---|
| **A. Agente único** (recomendada para empezar) | Uso diario; menos configuración | 1: "Arquitecto Process One" con A9 |
| **B. Multiagente** | Cuando quieras especialistas con conocimiento separado y respuestas más precisas | 1 orquestador (A0) + 3 agentes conectados (A1, A2, A3) |

Ambas producen lo mismo: un **paquete de cambios** que pegas en `Estudio_ProcessOne.html` para obtener el Word, el XML y los diagramas.

## 1. Opción A – Agente único
1. **Crear → Nuevo agente → Configurar** (sin el asistente conversacional).
2. **Nombre**: Arquitecto Process One. **Descripción**: Genera paquetes de cambios para el ADD de Process One y su modelo ArchiMate (formato corporativo, APIs OnBase/TMF667, datos y diagramas).
3. **Instrucciones**: pega `A9_instrucciones_agente_unico.md` (límite de Copilot Studio: 8.000 caracteres).
4. **Modelo**: el modelo OpenAI de mayor capacidad disponible (familia GPT-5 o GPT-4.1). **Orquestación generativa**: activada.
5. **Conocimiento** (Agregar conocimiento → Cargar archivos): todos los archivos de `conocimiento/` y de `datos/`:
   K01…K07 (.md), K08_indice_bloques_ADD.txt, K09 (.md), add_processone.json, modelo_processone.json, openapi_fachada_onbase_tmf667.yaml y referencia/ADD_Process_One_v0.9.1.docx.
   Si algún tipo de archivo es rechazado (.md, .json, .yaml), cambia la extensión a `.txt`; el contenido es texto.
6. **Configuración → IA generativa**: permitir que los usuarios **carguen archivos** (para adjuntar plantillas, WSDL, especificación TMF667). **Búsqueda web**: desactivada (datos internos).
7. **Frases de inicio**: copia las de `03_pruebas_y_frases_de_inicio.md`.
8. Prueba en el panel **Probar** con P1–P10 y luego **Publicar** en **Microsoft Teams** (solo para ti o tu equipo).

## 2. Opción B – Multiagente
Crea primero los tres especialistas (cada uno es un agente completo con su propio conocimiento):
| Agente | Instrucciones | Conocimiento | Descripción (la usa el orquestador para decidir) |
|---|---|---|---|
| PO Editor ADD | A1 | K08, add_processone.json, K09, K02, K06, K07, K01, ADD .docx | Edita el ADD de Process One: genera operaciones "add" del paquete de cambios, adapta al formato corporativo, actualiza tablas, secciones, versiones y pendientes. |
| PO Modelador ArchiMate | A2 | modelo_processone.json, K03, K09, K01 | Modela en ArchiMate 3.2: genera operaciones "archimate" (elementos, relaciones válidas, vistas y posiciones) para el modelo de Process One. |
| PO Integración y Datos | A3 | K04, K05, openapi_fachada_onbase_tmf667.yaml, K01, K08, K09, K03 | Analiza APIs de OnBase y TMF667, define la fachada REST, datos, consultas y consumos, y genera operaciones "add" y "archimate" de integración. |

En cada especialista: **Configuración → Agente conectado** (o equivalente): habilitar "Permitir que otros agentes se conecten y usen este agente". Publícalos.

Luego el orquestador:
1. Crea "Arquitecto Process One" con las instrucciones A0 y conocimiento K01, K08, K09 (para que pueda integrar y verificar).
2. **Agentes → Agregar un agente → Agente de Copilot Studio** → selecciona los tres especialistas (deben estar en el mismo entorno).
3. Orquestación generativa activada; carga de archivos activada.
4. Publica en Teams.

Alternativa: si tu tenant ofrece **agentes secundarios (child agents)** dentro de un mismo agente, puedes crear los tres especialistas ahí con las mismas instrucciones; verifica que cada uno pueda usar su conocimiento.

## 3. Ciclo de trabajo (ambas opciones)
1. En Teams: pide el cambio y adjunta la fuente (plantilla, WSDL, especificación, acta).
2. El agente responde: Resumen → **paquete JSON** → Pendientes.
3. Abre `Estudio_ProcessOne.html` (doble clic, Edge). La primera vez usa el proyecto incluido; después carga tu `proyecto_processone.json`.
4. Pega el paquete → **Aplicar paquete**. Si hay errores: **Copiar errores para el agente** y pégalos en el chat; el agente reentrega el paquete completo.
5. Pestaña **Datos confidenciales**: escribe IPs, rangos, cuentas y nombres (solo en tu equipo). Guarda esos valores con **Guardar valores** en una carpeta segura.
6. **Word del ADD**, **XML para Archi**, **PNG de todas las vistas**.
7. **Guardar proyecto** (proyecto_processone.json) y **Conocimiento para el agente**: reemplaza en Copilot Studio `add_processone.json`, `K08_indice_bloques_ADD.txt` y `modelo_processone.json`. Sin este paso el agente trabajará sobre la versión anterior.
8. Archi: File → Import → Open Exchange XML Model → Save As `.archimate`. Si prefieres las imágenes de Archi en el Word, expórtalas desde Archi y súbelas en la pestaña **Figuras** del Estudio.

## 4. Si el agente no responde bien
| Síntoma | Corrección |
|---|---|
| Inventa id de bloques | Verifica que K08 esté cargado y actualizado; pídele "usa solo id de K08" |
| Devuelve texto en vez de paquete | Recuérdale: "entrega el paquete K09" (la prueba P5 lo cubre) |
| Relaciones ArchiMate inválidas | Pega los errores del Estudio; confirma que K03 esté cargado completo (incluye K03-A) |
| Olvida actualizar el modelo al cambiar la arquitectura | Pídele "incluye la parte archimate" o usa la Opción B |
| Paquetes demasiado grandes | Pide "un paquete por capítulo" |
