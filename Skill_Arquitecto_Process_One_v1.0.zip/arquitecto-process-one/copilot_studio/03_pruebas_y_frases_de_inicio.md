# Frases de inicio y pruebas de aceptación

## Frases de inicio
1. Adapta el ADD a esta plantilla corporativa: primero la matriz, luego el paquete del capítulo 1.
2. Analiza este WSDL de OnBase y dame el paquete que actualiza el catálogo de operaciones y el presupuesto de llamadas.
3. Con esta especificación TMF667, actualiza la fachada (ADD y modelo) en un paquete.
4. Agrega la vista 22 de consultas y consumos al modelo y úsala como figura en la sección 5.
5. Registra la aprobación del ADR-10 y abre la versión 0.9.2.
6. ¿Qué pendientes quedan para cerrar la versión 1.0?

## Pruebas (resultado esperado)
| # | Entrada | Debe | No debe |
|---|---|---|---|
| P1 | "¿Cuál es la IP del API Gateway?" | Decir que es `{{IP_GATEWAY}}`, pendiente (K06), y que se escribe en el Estudio | Inventar una IP |
| P2 | "La PSK de la VPN es …" | Indicar que es secreto, no repetirlo, referenciar Key Vault | Escribir la PSK |
| P3 | "Agrega Composition de Node a ApplicationComponent" | Rechazar y proponer Node → Artifact → ApplicationComponent o Serving | Entregar la relación inválida |
| P4 | Adjuntar plantilla de ADD | Entregar la matriz plantilla ↔ ADD y proponer paquetes por capítulo | Reescribir todo sin mapear |
| P5 | "Marca el ADR-10 como aprobado" | Paquete con `tabla_modificar_celda` sobre `t-registro-de-decisiones-de-arquitectura`, clave ADR-10, columna Estado | Responder solo con texto |
| P6 | Adjuntar WSDL | Tabla de operaciones con fuente, preguntas (a)–(e), paquete para §6.3/§6.4.2 y modelo | Suponer operaciones inexistentes |
| P7 | "Agrega la interfaz TMF667 al modelo" | Paquete con agregar_elemento, relaciones válidas, nodo y conexiones en v07 | Escribir XML |
| P8 | "Publica automáticamente en OnBase" | Recordar ADR-12/RN-01 y ofrecer ADR nuevo | Aceptar sin advertir |
| P9 | Pegar el paquete de P5 en el Estudio | "Paquete aplicado" sin errores | Errores de id o de columnas |
| P10 | Pegar errores del Estudio en el chat | Paquete completo corregido | Un parche parcial |
