---
name: arquitecto-process-one
description: Skill para agentes de Copilot Studio que actualizan, corrigen y completan el ADD de Process One y su modelo ArchiMate. El agente entrega paquetes de cambios JSON; la herramienta local Estudio_ProcessOne.html los valida y genera el Word del ADD, el XML para Archi y los diagramas, con los datos confidenciales aplicados solo en el equipo del usuario.
version: 1.0.0
---

# Skill: Arquitecto Process One

## Qué resuelve
| Necesidad | Cómo |
|---|---|
| Actualizar, corregir y adicionar datos al ADD | Operaciones `add` del paquete (K09) sobre bloques con id estables (K08) |
| Adaptar al formato corporativo | Matriz plantilla ↔ ADD y paquetes por capítulo (K02) |
| Corregir y actualizar diagramas y XML | Operaciones `archimate` validadas contra ArchiMate 3.2 (K03); figuras del ADD pueden dibujarse desde las vistas |
| APIs OnBase, TMF667, datos y consumos | K04, K05 y el contrato OpenAPI |
| Datos confidenciales (IPs, cuentas, nombres) | Se escriben solo en el Estudio, nunca pasan por el agente |
| Sin Python ni instalaciones | El Estudio es un HTML que funciona sin conexión en Edge |

## Estructura
```
arquitecto-process-one/
├── SKILL.md
├── LEEME_PRIMERO.md                      ← puesta en marcha en 15 minutos
├── copilot_studio/
│   ├── 02_guia_configuracion_copilot_studio.md
│   ├── 03_pruebas_y_frases_de_inicio.md
│   ├── A9_instrucciones_agente_unico.md  ← Opción A (recomendada para empezar)
│   ├── A0_instrucciones_orquestador.md   ← Opción B (multiagente)
│   ├── A1_instrucciones_editor_add.md
│   ├── A2_instrucciones_modelador_archimate.md
│   └── A3_instrucciones_integracion_datos.md
├── conocimiento/                         ← subir al agente
│   ├── K01…K07 (contexto, formato corporativo, ArchiMate, TMF667, datos, pendientes, plantillas)
│   ├── K08_indice_bloques_ADD.txt        ← se regenera con el Estudio
│   └── K09_contrato_paquete_cambios.md   ← contrato de salida del agente
├── datos/                                ← subir al agente (se regeneran con el Estudio)
│   ├── add_processone.json
│   ├── modelo_processone.json
│   └── openapi_fachada_onbase_tmf667.yaml
├── herramientas/
│   ├── Estudio_ProcessOne.html           ← paquete → Word + XML + PNG
│   └── opcional_python/                  ← mismo motor ArchiMate en Python (no requerido)
└── referencia/ADD_Process_One_v0.9.1.docx
```

## Reglas no negociables del agente
1. Entrega siempre un paquete JSON (K09); nunca Word ni XML escritos a mano.
2. Solo usa id de bloque existentes en K08 y relaciones permitidas en K03-A.
3. No inventa datos confidenciales (usa `{{MARCADOR}}`); nunca escribe secretos.
4. Si cambia la arquitectura, actualiza documento y modelo en el mismo paquete.
5. Si el Estudio reporta errores, reentrega el paquete completo corregido.

## Versionado
- Tras cada sesión: en el Estudio, **Conocimiento para el agente** y reemplazar `add_processone.json`, `K08_indice_bloques_ADD.txt` y `modelo_processone.json` en Copilot Studio.
- Versión del ADD: 0.9.x mientras haya marcadores pendientes; 1.0 con datos reales completos.
