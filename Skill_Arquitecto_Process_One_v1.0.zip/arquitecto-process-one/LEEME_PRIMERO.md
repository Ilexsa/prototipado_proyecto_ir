# Puesta en marcha (15 minutos)

1. **Probar el Estudio** (2 min): doble clic en `herramientas/Estudio_ProcessOne.html` → botón **Word del ADD** → debe descargar el ADD v0.9.1. Botón **XML para Archi** → importar en Archi con File → Import → Open Exchange XML Model.
2. **Crear el agente** (10 min): seguir `copilot_studio/02_guia_configuracion_copilot_studio.md`, Opción A (agente único) con las instrucciones `A9_instrucciones_agente_unico.md` y todos los archivos de `conocimiento/` y `datos/`.
3. **Primera prueba** (3 min): en el agente, escribir *"Marca el ADR-10 como aprobado y abre la versión 0.9.2"*. Copiar el paquete JSON de la respuesta → Estudio → **Aplicar paquete** → **Word del ADD**. La tabla de ADR debe mostrar ADR-10 "Aprobada" y el historial la versión 0.9.2.
4. **Cerrar el ciclo**: en el Estudio, **Guardar proyecto** y **Conocimiento para el agente**; reemplazar los tres archivos en el conocimiento del agente.

Datos confidenciales: se escriben en la pestaña **Datos confidenciales** del Estudio y se guardan aparte con **Guardar valores**. No los compartas con el agente.
