#!/usr/bin/env python3
"""
generar_archimate.py – Genera un modelo ArchiMate 3.2 en Open Exchange Format 3.1 (XML importable en Archi)
a partir de un modelo JSON (fuente de verdad editable por personas o por un agente de IA).

Uso:
    python generar_archimate.py modelo_processone.json -o ProcessOne_ArchiMate.xml
    python generar_archimate.py modelo_processone.json --solo-validar
    python generar_archimate.py modelo_processone.json --cambios paquete.json -o ProcessOne_ArchiMate.xml --guardar-modelo modelo_nuevo.json

Sin Python: abrir Generador_ArchiMate_ProcessOne.html en Edge/Chrome (mismo motor, sin instalación ni conexión).

Qué valida:
    1. Tipos de elemento ArchiMate válidos.
    2. Cada relación contra la tabla oficial de relaciones permitidas de ArchiMate 3.2 (reglas/relaciones_archimate_3_2.json).
    3. Referencias: nodos de vista -> elementos; conexiones -> relaciones existentes.
    4. Layout: solapamientos de nodos y conexiones que atraviesan elementos ajenos (advertencias).
    5. XSD oficial de The Open Group (si lxml está instalado; carpeta xsd/).

Importar en Archi: File -> Import -> Open Exchange XML Model (NO usar File -> Open).
Requisitos: Python 3.9+. Opcional: pip install lxml (validación XSD).
"""
import argparse, json, os, re, sys, textwrap
from xml.sax.saxutils import escape

AQUI = os.path.dirname(os.path.abspath(__file__))
R = json.load(open(os.path.join(AQUI, 'reglas', 'relaciones_archimate_3_2.json'), encoding='utf-8'))
REGLAS, LETRA = R['reglas'], {v: k for k, v in R['letras'].items()}

CAPA = {}
for t in 'Stakeholder Driver Assessment Goal Outcome Principle Requirement Constraint Meaning Value'.split(): CAPA[t] = 'mot'
for t in 'Resource Capability ValueStream CourseOfAction'.split(): CAPA[t] = 'str'
for t in ('BusinessActor BusinessRole BusinessCollaboration BusinessInterface BusinessProcess BusinessFunction BusinessInteraction '
          'BusinessEvent BusinessService BusinessObject Contract Representation Product').split(): CAPA[t] = 'bus'
for t in ('ApplicationComponent ApplicationCollaboration ApplicationInterface ApplicationFunction ApplicationInteraction '
          'ApplicationProcess ApplicationEvent ApplicationService DataObject').split(): CAPA[t] = 'app'
for t in ('Node Device SystemSoftware TechnologyCollaboration TechnologyInterface Path CommunicationNetwork TechnologyFunction '
          'TechnologyProcess TechnologyInteraction TechnologyEvent TechnologyService Artifact Equipment Facility DistributionNetwork Material').split(): CAPA[t] = 'tec'
for t in 'WorkPackage Deliverable ImplementationEvent'.split(): CAPA[t] = 'imp'
for t in 'Plateau Gap'.split(): CAPA[t] = 'mig'
CAPA.update({'Location': 'loc', 'Grouping': 'grp', 'AndJunction': 'jun', 'OrJunction': 'jun'})
COLOR = {'mot': (204, 204, 255), 'str': (245, 222, 170), 'bus': (255, 255, 181), 'app': (181, 255, 255), 'tec': (201, 231, 183),
         'imp': (255, 224, 224), 'mig': (224, 255, 224), 'loc': (251, 184, 117), 'grp': (250, 250, 250), 'jun': (0, 0, 0)}
VIEWPOINTS = {'Organization', 'Application Platform', 'Application Structure', 'Information Structure', 'Technology', 'Layered', 'Physical',
              'Product', 'Application Usage', 'Technology Usage', 'Business Process Cooperation', 'Application Cooperation',
              'Service Realization', 'Implementation and Deployment', 'Goal Realization', 'Goal Contribution', 'Principles',
              'Requirements Realization', 'Motivation', 'Strategy', 'Capability Map', 'Outcome Realization', 'Resource Map',
              'Value Stream', 'Project', 'Migration', 'Implementation and Migration', 'Stakeholder'}

errores, avisos = [], []
def err(m): errores.append(m)
def warn(m): avisos.append(m)
def sid(s): return re.sub(r'[^A-Za-z0-9_.-]', '-', s)
def base(k): return k.split('@')[0]
def concepto(t): return 'Junction' if t.endswith('Junction') else t

def rel_id(r):
    x = 'id-r-%s-%s-%s' % (r['type'][:3].lower(), sid(r['source']), sid(r['target']))
    if r.get('name'): x += '-' + re.sub(r'[^a-z0-9]+', '-', r['name'].lower())[:20].strip('-')
    return x

# ------------------------------------------------------------------ carga y validación del modelo
def cargar(ruta):
    M = json.load(open(ruta, encoding='utf-8'))
    E = {}
    for e in M['elements']:
        if e['id'] in E: err(f"Elemento duplicado: {e['id']}")
        if e['type'] not in CAPA: err(f"Tipo de elemento inválido: {e['type']} ({e['id']})")
        E[e['id']] = e
    RL, vistos = [], set()
    for r in M['relationships']:
        for lado in ('source', 'target'):
            if r[lado] not in E: err(f"Relación {r['type']} {r['source']}->{r['target']}: '{r[lado]}' no existe")
        if errores: continue
        ts, tt = concepto(E[r['source']]['type']), concepto(E[r['target']]['type'])
        if r['type'] not in LETRA: err(f"Tipo de relación inválido: {r['type']}"); continue
        if LETRA[r['type']] not in (REGLAS.get(ts, {}).get(tt) or ''):
            permit = [k for k, v in LETRA.items() if v in (REGLAS.get(ts, {}).get(tt) or '')]
            err(f"Relación NO permitida por ArchiMate 3.2: {r['type']} {ts}({r['source']}) -> {tt}({r['target']}). Permitidas: {permit}")
        r['_id'] = rel_id(r)
        if r['_id'] in vistos: err(f"Relación duplicada: {r['_id']}")
        vistos.add(r['_id']); RL.append(r)
    return M, E, RL

def resolver(RL, tipo, s, t, nombre=None):
    c = [r for r in RL if r['type'] == tipo and r['source'] == s and r['target'] == t and (nombre is None or r.get('name', '') == nombre)]
    return c[0] if len(c) == 1 else (None if not c else 'ambigua')

# ------------------------------------------------------------------ layout en grilla
def tam(E, k, cw, rh):
    e = E[base(k)]
    if e['type'].endswith('Junction'): return 15, 15
    n = len(e['name']); w0 = 150 if n <= 26 else (180 if n <= 44 else 210)
    w = min(w0, int(cw * 0.86))
    lineas = len(textwrap.wrap(e['name'], max(10, int(w / 6.6))))
    h = 55 if lineas <= 2 else 55 + (lineas - 2) * 13
    return w, min(h, int(rh * 0.9))

def layout(E, v):
    cw, rh = v.get('cw', 170), v.get('rh', 100)
    pos, par = {}, {}
    def walk(nodos, padre):
        cajas = []
        for n in nodos:
            k = n.get('as', n['ref']); par[k] = padre
            if n.get('children'):
                cb = walk(n['children'], k)
                x0 = min(b[0] for b in cb) - 14; y0 = min(b[1] for b in cb) - 30
                x1 = max(b[0] + b[2] for b in cb) + 14; y1 = max(b[1] + b[3] for b in cb) + 14
                pos[k] = [x0, y0, x1 - x0, y1 - y0]
            else:
                if 'at' not in n: err(f"Vista {v['id']}: el nodo {k} no tiene 'at' [col, fila]"); continue
                w, h = tam(E, k, cw, rh); c, r_ = n['at']
                pos[k] = [c * cw - w / 2, r_ * rh - h / 2, w, h]
            cajas.append(pos[k])
        return cajas
    walk(v['nodes'], None)
    bps = [(c * cw, r_ * rh) for cn in v.get('connections', []) for c, r_ in cn.get('bends', [])]
    mx = min([p[0] for p in pos.values()] + [b[0] for b in bps] + [0]); my = min([p[1] for p in pos.values()] + [b[1] for b in bps] + [0])
    dx, dy = 30 - mx, 30 - my
    pos = {k: [int(round(x + dx)), int(round(y + dy)), int(round(w)), int(round(h))] for k, (x, y, w, h) in pos.items()}
    conv = lambda c, r_: (int(round(c * cw + dx)), int(round(r_ * rh + dy)))
    return pos, par, conv

def revisar_layout(v, pos, par, cons, cont):
    def anc(k):
        s = set()
        while par.get(k): k = par[k]; s.add(k)
        return s
    ks = list(pos)
    for i, a in enumerate(ks):
        for b in ks[i + 1:]:
            if a in anc(b) or b in anc(a): continue
            ax, ay, aw, ah = pos[a]; bx, by, bw, bh = pos[b]
            if ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah: warn(f"Vista {v['id']}: solapan {a} y {b}")
    hojas = [k for k in ks if k not in cont]
    for (a, b, pts) in cons:
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            for k in hojas:
                if k in (a, b) or a in anc(k) or b in anc(k): continue
                x, y, w, h = pos[k]; x -= 3; y -= 3; w += 6; h += 6
                if any(x < x0 + (x1 - x0) * t / 60 < x + w and y < y0 + (y1 - y0) * t / 60 < y + h for t in range(61)):
                    warn(f"Vista {v['id']}: la conexión {a}->{b} atraviesa {k}"); break

# ------------------------------------------------------------------ exportación
def exportar(M, E, RL, salida):
    X, L = [], 'xml:lang="es"'
    w = X.append
    def txt(tag, val, ind):
        if val: w(f'{ind}<{tag} {L}>{escape(val)}</{tag}>')
    props = {}
    for e in M['elements']:
        for p in e.get('props', {}): props.setdefault(p, 'propid-%d' % (len(props) + 1))
    w('<?xml version="1.0" encoding="UTF-8"?>')
    w('<model xmlns="http://www.opengroup.org/xsd/archimate/3.0/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
      'xsi:schemaLocation="http://www.opengroup.org/xsd/archimate/3.0/ http://www.opengroup.org/xsd/archimate/3.1/archimate3_Diagram.xsd" '
      f'identifier="id-model-{sid(M["meta"].get("id", "modelo"))}">')
    txt('name', M['meta']['name'], '  '); txt('documentation', M['meta'].get('documentation', ''), '  ')
    w('  <elements>')
    for e in M['elements']:
        w(f'    <element identifier="id-{sid(e["id"])}" xsi:type="{e["type"]}">')
        txt('name', e['name'], '      '); txt('documentation', e.get('doc', ''), '      ')
        if e.get('props'):
            w('      <properties>')
            for p, val in e['props'].items():
                w(f'        <property propertyDefinitionRef="{props[p]}"><value {L}>{escape(str(val))}</value></property>')
            w('      </properties>')
        w('    </element>')
    w('  </elements>')
    w('  <relationships>')
    for r in RL:
        extra = ''
        if r['type'] == 'Access' and r.get('accessType'): extra = f' accessType="{r["accessType"]}"'
        if r['type'] == 'Association' and r.get('directed'): extra = ' isDirected="true"'
        body = (f'<name {L}>{escape(r["name"])}</name>' if r.get('name') else '') + (f'<documentation {L}>{escape(r["doc"])}</documentation>' if r.get('doc') else '')
        w(f'    <relationship identifier="{r["_id"]}" source="id-{sid(r["source"])}" target="id-{sid(r["target"])}" xsi:type="{r["type"]}"{extra}' + (f'>{body}</relationship>' if body else ' />'))
    w('  </relationships>')
    carpetas = [('Estrategia', ('str',)), ('Negocio', ('bus',)), ('Aplicación', ('app',)), ('Tecnología y física', ('tec',)), ('Motivación', ('mot',)),
                ('Implementación y migración', ('imp', 'mig')), ('Otros', ('loc', 'grp', 'jun'))]
    w('  <organizations>')
    for lab, capas in carpetas:
        ks = [e for e in M['elements'] if CAPA[e['type']] in capas]
        if not ks: continue
        w(f'    <item><label {L}>{lab}</label>')
        for e in ks: w(f'      <item identifierRef="id-{sid(e["id"])}" />')
        w('    </item>')
    w(f'    <item><label {L}>Relaciones</label>')
    for r in RL: w(f'      <item identifierRef="{r["_id"]}" />')
    w('    </item>')
    w(f'    <item><label {L}>Vistas</label>')
    for v in M['views']: w(f'      <item identifierRef="id-v-{sid(v["id"])}" />')
    w('    </item>')
    w('  </organizations>')
    if props:
        w('  <propertyDefinitions>')
        for p, pid in props.items(): w(f'    <propertyDefinition identifier="{pid}" type="string"><name {L}>{escape(p)}</name></propertyDefinition>')
        w('  </propertyDefinitions>')
    w('  <views>'); w('    <diagrams>')
    for v in M['views']:
        vid = f'id-v-{sid(v["id"])}'
        vp = v.get('viewpoint')
        if vp and vp not in VIEWPOINTS: warn(f"Vista {v['id']}: viewpoint '{vp}' no estándar; se omite"); vp = None
        w(f'      <view identifier="{vid}" xsi:type="Diagram"' + (f' viewpoint="{vp}"' if vp else '') + '>')
        txt('name', v['name'], '        '); txt('documentation', v.get('doc', ''), '        ')
        pos, par, conv = layout(E, v)
        nid, cont = {}, []
        def nodos(lista, ind):
            for n in lista:
                k = n.get('as', n['ref'])
                if n['ref'] not in E: err(f"Vista {v['id']}: el nodo '{n['ref']}' no es un elemento del modelo"); continue
                if k in nid: err(f"Vista {v['id']}: nodo repetido '{k}' (use 'as' para repetir un elemento)"); continue
                if k not in pos: continue
                e = E[n['ref']]; x, y, ww, hh = pos[k]; c = COLOR[CAPA[e['type']]]
                nid[k] = f'{vid}-n-{sid(k)}'
                w(f'{ind}<node identifier="{nid[k]}" elementRef="id-{sid(e["id"])}" xsi:type="Element" x="{x}" y="{y}" w="{ww}" h="{hh}">')
                w(f'{ind}  <style><fillColor r="{c[0]}" g="{c[1]}" b="{c[2]}" /><lineColor r="92" g="92" b="92" /><font name="Segoe UI" size="9"><color r="0" g="0" b="0" /></font></style>')
                if n.get('children'): cont.append(k); nodos(n['children'], ind + '  ')
                w(f'{ind}</node>')
        nodos(v['nodes'], '        ')
        cons = []
        for cn in v.get('connections', []):
            a, b = cn['source'], cn['target']
            if a not in nid or b not in nid: err(f"Vista {v['id']}: conexión {a}->{b} con nodo inexistente en la vista"); continue
            r = resolver(RL, cn['type'], base(a), base(b), cn.get('name'))
            if r is None: err(f"Vista {v['id']}: no existe la relación {cn['type']} {base(a)}->{base(b)}; créela primero en 'relationships'"); continue
            if r == 'ambigua': err(f"Vista {v['id']}: varias relaciones {cn['type']} {base(a)}->{base(b)}; indique 'name'"); continue
            bp = [conv(c, r_) for c, r_ in cn.get('bends', [])]
            ca = (pos[a][0] + pos[a][2] / 2, pos[a][1] + pos[a][3] / 2); cb = (pos[b][0] + pos[b][2] / 2, pos[b][1] + pos[b][3] / 2)
            cons.append((a, b, [ca] + bp + [cb]))
            w(f'        <connection identifier="{vid}-c-{sid(a)}-{sid(b)}-{cn["type"][:3].lower()}{"-" + sid(cn["name"]) if cn.get("name") else ""}" relationshipRef="{r["_id"]}" xsi:type="Relationship" source="{nid[a]}" target="{nid[b]}">')
            w('          <style><lineColor r="64" g="64" b="64" /></style>')
            for (x, y) in bp: w(f'          <bendpoint x="{x}" y="{y}" />')
            w('        </connection>')
        revisar_layout(v, pos, par, cons, cont)
        w('      </view>')
    w('    </diagrams>'); w('  </views>'); w('</model>')
    if salida: open(salida, 'w', encoding='utf-8').write('\n'.join(X))
    return '\n'.join(X)

def validar_xsd(ruta):
    try:
        from lxml import etree
    except ImportError:
        warn('lxml no instalado: se omite la validación XSD (pip install lxml)'); return
    xsd = os.path.join(AQUI, 'xsd', 'archimate3_Diagram.xsd')
    s = etree.XMLSchema(etree.parse(xsd))
    if not s.validate(etree.parse(ruta)):
        for e in list(s.error_log)[:20]: err(f'XSD línea {e.line}: {e.message}')

def base_n(n): return base(n.get('as', n['ref']))
def aplicar_cambios(M, P):
    import copy
    M = copy.deepcopy(M); log, errs = [], []
    el = lambda i: next((e for e in M['elements'] if e['id'] == i), None)
    def quitar(nodos, pred):
        out = []
        for n in nodos:
            if pred(n): continue
            if n.get('children'): n = dict(n, children=quitar(n['children'], pred))
            out.append(n)
        return out
    def buscar(nodos, k):
        for n in nodos:
            if n.get('as', n['ref']) == k: return n
            if n.get('children'):
                r = buscar(n['children'], k)
                if r: return r
        return None
    vista = lambda i: next((v for v in M['views'] if v['id'] == i), None)
    for i, o in enumerate(P.get('operaciones', []), 1):
        tag = f"#{i} {o.get('op')}"; op = o.get('op')
        if op == 'agregar_elemento':
            if el(o['elemento']['id']): errs.append(f"{tag}: ya existe {o['elemento']['id']}"); continue
            M['elements'].append(o['elemento'])
        elif op == 'modificar_elemento':
            e = el(o['id'])
            if not e: errs.append(f"{tag}: no existe {o['id']}"); continue
            c = o.get('cambios', {})
            for k in ('name', 'doc', 'type'):
                if c.get(k) is not None: e[k] = c[k]
            if c.get('props'):
                e['props'] = {**e.get('props', {}), **c['props']}
                e['props'] = {k: v for k, v in e['props'].items() if v is not None}
        elif op == 'eliminar_elemento':
            if not el(o['id']): errs.append(f"{tag}: no existe {o['id']}"); continue
            M['elements'] = [e for e in M['elements'] if e['id'] != o['id']]
            M['relationships'] = [r for r in M['relationships'] if o['id'] not in (r['source'], r['target'])]
            for v in M['views']:
                v['nodes'] = quitar(v['nodes'], lambda n: base_n(n) == o['id'] or n['ref'] == o['id'])
                v['connections'] = [c for c in v.get('connections', []) if o['id'] not in (base(c['source']), base(c['target']))]
        elif op == 'agregar_relacion':
            r = o['relacion']
            if not any(x['type'] == r['type'] and x['source'] == r['source'] and x['target'] == r['target'] and x.get('name', '') == r.get('name', '') for x in M['relationships']):
                M['relationships'].append(r)
        elif op == 'eliminar_relacion':
            n0 = len(M['relationships'])
            M['relationships'] = [r for r in M['relationships'] if not (r['type'] == o['type'] and r['source'] == o['source'] and r['target'] == o['target'] and (o.get('name') is None or r.get('name', '') == o['name']))]
            for v in M['views']:
                v['connections'] = [c for c in v.get('connections', []) if not (c['type'] == o['type'] and base(c['source']) == o['source'] and base(c['target']) == o['target'])]
            if len(M['relationships']) == n0: errs.append(f'{tag}: no encontrada'); continue
        elif op in ('agregar_vista', 'reemplazar_vista'):
            M['views'] = [v for v in M['views'] if v['id'] != o['vista']['id']] + [o['vista']] if not vista(o['vista']['id']) else [o['vista'] if v['id'] == o['vista']['id'] else v for v in M['views']]
        elif op == 'eliminar_vista':
            M['views'] = [v for v in M['views'] if v['id'] != o['id']]
        elif op == 'agregar_nodo':
            v = vista(o['vista'])
            if not v: errs.append(f"{tag}: vista {o['vista']} no existe"); continue
            if o.get('dentro_de'):
                p = buscar(v['nodes'], o['dentro_de'])
                if not p: errs.append(f"{tag}: contenedor {o['dentro_de']} no está"); continue
                p.setdefault('children', []).append(o['nodo'])
            else: v['nodes'].append(o['nodo'])
        elif op == 'mover_nodo':
            v = vista(o['vista']); n = v and buscar(v['nodes'], o['nodo'])
            if not n: errs.append(f"{tag}: nodo {o['nodo']} no está en {o['vista']}"); continue
            n['at'] = o['at']
        elif op == 'quitar_nodo':
            v = vista(o['vista'])
            if not v: errs.append(f"{tag}: vista {o['vista']} no existe"); continue
            v['nodes'] = quitar(v['nodes'], lambda n: n.get('as', n['ref']) == o['nodo'])
            v['connections'] = [c for c in v.get('connections', []) if o['nodo'] not in (c['source'], c['target'])]
        elif op == 'agregar_conexion':
            v = vista(o['vista'])
            if not v: errs.append(f"{tag}: vista {o['vista']} no existe"); continue
            v.setdefault('connections', []).append(o['conexion'])
        elif op == 'quitar_conexion':
            v = vista(o['vista'])
            if not v: errs.append(f"{tag}: vista {o['vista']} no existe"); continue
            v['connections'] = [c for c in v.get('connections', []) if not (c['type'] == o['type'] and c['source'] == o['source'] and c['target'] == o['target'])]
        elif op == 'modificar_meta':
            M['meta'].update(o.get('cambios', {}))
        else:
            errs.append(f'{tag}: operación desconocida'); continue
        log.append(tag)
    if P.get('version'): M['meta']['version'] = P['version']
    return M, log, errs

def main():
    ap = argparse.ArgumentParser(description='JSON -> ArchiMate Open Exchange XML validado')
    ap.add_argument('modelo'); ap.add_argument('-o', '--salida', default=None); ap.add_argument('--solo-validar', action='store_true')
    ap.add_argument('--cambios', help='Paquete de cambios JSON a aplicar antes de generar')
    ap.add_argument('--guardar-modelo', help='Ruta para guardar el modelo JSON actualizado')
    a = ap.parse_args()
    ruta = a.modelo
    if a.cambios:
        M0 = json.load(open(a.modelo, encoding='utf-8'))
        P = json.load(open(a.cambios, encoding='utf-8'))
        M1, log, errs = aplicar_cambios(M0, P)
        for x in log: print('CAMBIO:', x)
        if errs:
            for x in errs: print('ERROR:', x)
            print('RESULTADO: el paquete de cambios tiene errores; no se aplicó.'); sys.exit(1)
        ruta = a.guardar_modelo or os.path.splitext(a.modelo)[0] + '_v' + M1['meta'].get('version', 'x') + '.json'
        json.dump(M1, open(ruta, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print('Modelo actualizado guardado en', ruta)
    M, E, RL = cargar(ruta)
    salida = None if a.solo_validar else (a.salida or os.path.splitext(ruta)[0] + '.xml')
    if not errores:
        exportar(M, E, RL, salida)
        if salida and not errores: validar_xsd(salida)
    print(f"Elementos: {len(M['elements'])} | Relaciones: {len(RL)} | Vistas: {len(M['views'])}")
    for x in avisos: print('AVISO:', x)
    for x in errores: print('ERROR:', x)
    if errores:
        print(f'RESULTADO: {len(errores)} error(es). No importe el XML hasta corregirlos.'); sys.exit(1)
    print('RESULTADO: OK' + (f' -> {salida}  (Archi: File > Import > Open Exchange XML Model)' if salida else ' (solo validación)'))

if __name__ == '__main__':
    main()
