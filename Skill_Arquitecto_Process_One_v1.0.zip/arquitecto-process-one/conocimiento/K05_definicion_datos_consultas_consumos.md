# K05 – Definición de datos, consultas y consumos

Objetivo: dejar explícito **qué dato vive dónde, quién lo consulta, cómo y cuánto cuesta** (en cuota de OnBase, tokens o RU/latencia). Complementa ADD §5 y §6.

## 1. Fuentes de verdad por dominio
| Dominio | Sistema de registro | Copia/uso en Azure | Sincronización |
|---|---|---|---|
| Documento oficial (vigente) | OnBase | Blob raw + índice + Azure SQL (metadatos) | Carga inicial + incremental por `lastUpdate` |
| Solicitud de actualización | SGP | Azure SQL (`solicitud`) | Manual en fase 1 (ADR-15) |
| Borradores, hallazgos, aprobaciones | Process One (Azure SQL + Blob outputs) | — | Transaccional |
| Revisión no vigente cargada | OnBase (tras carga) | Azure SQL (`carga_onbase`) | En el paso 10 |
| Conocimiento para RAG | Azure AI Search | — | Indexer cada {{15}} min |
| Hilos de conversación | Cosmos DB (Foundry) | — | TTL {{90}} días |

## 2. Diccionario de datos (Azure SQL, esquema `p1`)
| Tabla | Campo | Tipo | Nulo | Origen | Notas |
|---|---|---|---|---|---|
| solicitud | ticket_sgp (PK) | varchar(40) | No | SGP | Formato {{patrón del ticket}} |
| | solicitante | nvarchar(150) | Sí | SGP | Dato personal → minimizar |
| | ingeniero_asignado_oid | uniqueidentifier | Sí | Entra ID | Object ID, no nombre |
| | estado | varchar(30) | No | Process One | REGISTRADA, EN_ANALISIS, BORRADOR, EN_REVISION_AREAS, APROBADA_GERENCIAS, CARGADA, PUBLICADA, CERRADA |
| | fecha_registro / fecha_cierre | datetime2 | No/Sí | | Base del KPI de tiempo de ciclo |
| solicitud_documento | ticket_sgp, documento_id (PK compuesta) | | No | Paso 4 | Documentos impactados; `origen` = CHATBOT / MANUAL |
| documento | documento_id (PK, identity) | bigint | No | | |
| | onbase_doc_id (UK) | varchar(64) | No | OnBase `Document.id` | |
| | titulo, codigo_documental | nvarchar | | OnBase | |
| | tipo_documento_id, area_id | int (FK) | | OnBase | |
| | estado_vigencia | varchar(20) | No | OnBase `lifecycleState` | Vigente, Desactualizado, En revisión, Derogado |
| | fecha_ultima_revision | date | Sí | OnBase characteristic | Regla RN-04 |
| | security_groups | nvarchar(max) JSON | No | Mapeo Anexo E | Deny by default |
| version_documento | version_id (PK), documento_id (FK), numero_version, blob_uri, sha256, paginas, fecha_ingesta | | | Ingesta | UK (documento_id, sha256) → idempotencia |
| adjunto | adjunto_id (PK), documento_id (FK padre), onbase_doc_id, nombre_archivo, mime_type, blob_uri | | | `documentRelationship isAttachmentOf` | |
| checkpoint_ingesta | corrida_id, onbase_doc_id, estado, intentos, ultimo_error, actualizado | | | Ingesta | Reanudación sin repetir llamadas |
| ejecucion_analisis | ejecucion_id (PK), ticket_sgp (FK), origen, alcance, estado, costo_estimado_usd, inicio, fin | | | Backend | |
| invocacion_agente | invocacion_id, ejecucion_id, agente_id, prompt_version, modelo, tokens_entrada, tokens_salida, latencia_ms | | | Workers | FinOps |
| hallazgo | hallazgo_id, invocacion_id, categoria, severidad, descripcion, evidencia_cita, pagina, seccion, sugerencia, confianza | | | Agentes | Cita obligatoria (RN-02) |
| borrador | borrador_id, ticket_sgp, version_base_id, iteracion, blob_uri, sha256, estado | | | AG-15 / Ingeniero | Una fila por iteración (RN-13) |
| aprobacion | aprobacion_id, borrador_id, tipo (INGENIERO, AREA, GERENCIA), aprobador_oid, resultado, comentario, fecha | | | Web | RN-10 |
| carga_onbase | carga_id, borrador_id, onbase_doc_id_nuevo, sha256, estado, fecha, error | | | API de Ingesta | RN-14 |

### DDL de referencia (borrador)
```sql
CREATE SCHEMA p1;
CREATE TABLE p1.solicitud (
  ticket_sgp varchar(40) NOT NULL PRIMARY KEY,
  solicitante nvarchar(150) NULL,
  ingeniero_asignado_oid uniqueidentifier NULL,
  estado varchar(30) NOT NULL,
  fecha_registro datetime2 NOT NULL DEFAULT sysutcdatetime(),
  fecha_cierre datetime2 NULL);
CREATE TABLE p1.documento (
  documento_id bigint IDENTITY PRIMARY KEY,
  onbase_doc_id varchar(64) NOT NULL UNIQUE,
  titulo nvarchar(400) NOT NULL,
  codigo_documental nvarchar(60) NULL,
  tipo_documento_id int NOT NULL,
  area_id int NULL,
  estado_vigencia varchar(20) NOT NULL,
  fecha_ultima_revision date NULL,
  security_groups nvarchar(max) NOT NULL CHECK (ISJSON(security_groups) = 1));
CREATE TABLE p1.borrador (
  borrador_id uniqueidentifier NOT NULL PRIMARY KEY DEFAULT newsequentialid(),
  ticket_sgp varchar(40) NOT NULL REFERENCES p1.solicitud(ticket_sgp),
  version_base_id bigint NOT NULL,
  iteracion int NOT NULL,
  blob_uri nvarchar(1000) NOT NULL,
  sha256 char(64) NOT NULL,
  estado varchar(20) NOT NULL,
  CONSTRAINT uq_borrador UNIQUE (ticket_sgp, version_base_id, iteracion));
CREATE TABLE p1.aprobacion (
  aprobacion_id uniqueidentifier NOT NULL PRIMARY KEY DEFAULT newsequentialid(),
  borrador_id uniqueidentifier NOT NULL REFERENCES p1.borrador(borrador_id),
  tipo varchar(10) NOT NULL CHECK (tipo IN ('INGENIERO','AREA','GERENCIA')),
  aprobador_oid uniqueidentifier NOT NULL,
  resultado varchar(12) NOT NULL CHECK (resultado IN ('APROBADO','OBSERVADO','RECHAZADO')),
  comentario nvarchar(2000) NULL,
  fecha datetime2 NOT NULL DEFAULT sysutcdatetime());
```

## 3. Catálogo de consumos
| Consumidor | Operación | Filtros / parámetros | Frecuencia | Llamadas OnBase | Presupuesto |
|---|---|---|---|---|---|
| Ingesta – carga inicial | `GET /document` + `GET /document/{id}` + `GET …/content` | `documentType` del alcance; lista de 1.288 IDs | Una vez (ventana nocturna) | ≈ 1.882 | 450 req/h → ≈ 4,2 h |
| Ingesta – incremental | `GET /document?lastUpdate.gt={checkpoint}` + detalle y contenido de cambiados | `fields=id,version,lastUpdate` | Diario {{02:00}} | 1 + 2 × cambiados | {{cambios/día}} × 2 |
| Carga controlada (paso 10) | `POST /document` | ticket, relación con vigente | Por documento aprobado | {{1–2}} | Despreciable |
| Backend – tablero | SQL | por ticket, área, estado | En línea | 0 | < 1 s |
| AG-16 chatbot | AI Search híbrida + semántica | `estado_vigencia`, `security_groups` | En línea | 0 | p95 < 8 s |
| AG-16 impacto (paso 4) | AI Search con facetas `proceso`, `area` + términos del cambio | top 50, agrupar por `onbase_doc_id` | Por solicitud | 0 | — |
| AG-07/AG-08 | Vector similarity entre fragmentos | excluir mismo `parent_id` | Por análisis | 0 | — |
| Especialistas | AI Search del documento en análisis | `parent_id eq '{id}'` | Por invocación | 0 | tokens |

Fórmulas:
- Llamadas carga inicial = Σdocs (1 metadatos + n_binarios) + Σadjuntos (1 metadatos si aplica + 1 binario) + páginas de descubrimiento.
- Horas = llamadas / cuota efectiva (450 o la parte asignada si se comparte).
- Incremental diario = 1 (listado) + cambiados × (1 detalle + 1 contenido).

## 4. Consultas de referencia
### 4.1 TMF667 (fachada)
```http
GET /tmf-api/documentManagement/v4/document?documentType=Procedimiento&lastUpdate.gt=2026-10-01T00:00:00Z&fields=id,name,version,lastUpdate,lifecycleState&offset=0&limit=100
GET /tmf-api/documentManagement/v4/document/{id}
GET /tmf-api/documentManagement/v4/document/{id}/attachment/{attachmentId}/content
POST /tmf-api/documentManagement/v4/document
{ "name": "…", "documentType": "Procedimiento", "lifecycleState": "{{estado no vigente}}",
  "externalIdentifier": [{"id": "{{ticket}}", "owner": "SGP", "externalIdentifierType": "ticketSGP"}],
  "documentRelationship": [{"relationshipType": "isRevisionOf", "document": {"id": "{{id vigente}}"}}],
  "attachment": [{"name": "….docx", "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "content": "<base64>"}] }
```
### 4.2 Azure AI Search (API REST; api-version {{2024-07-01 o posterior – verificar}})
Consulta del chatbot (híbrida + semántica + seguridad):
```json
POST /indexes/idx-processone-chunks/docs/search?api-version={{version}}
{
  "search": "¿Cuál es el procedimiento vigente para …?",
  "queryType": "semantic",
  "semanticConfiguration": "sem-processone",
  "vectorQueries": [{"kind": "text", "text": "¿Cuál es el procedimiento vigente para …?", "fields": "content_vector", "k": 50}],
  "filter": "estado_vigencia eq 'Vigente' and security_groups/any(g: search.in(g, '{{oid1}},{{oid2}}'))",
  "select": "title,content,section_path,page_number,onbase_doc_id,version",
  "captions": "extractive",
  "top": 8
}
```
Análisis de impacto (paso 4): mismo patrón con `"facets": ["proceso,count:20", "area,count:20"]`, `top: 50`, y agrupación por `onbase_doc_id` en el agente.
### 4.3 SQL de indicadores
```sql
-- Tiempo de ciclo por solicitud (KPI)
SELECT ticket_sgp, DATEDIFF(day, fecha_registro, fecha_cierre) AS dias FROM p1.solicitud WHERE fecha_cierre IS NOT NULL;
-- Iteraciones hasta la aprobación del Ingeniero
SELECT b.ticket_sgp, MAX(b.iteracion) AS iteraciones
FROM p1.borrador b JOIN p1.aprobacion a ON a.borrador_id = b.borrador_id AND a.tipo = 'INGENIERO' AND a.resultado = 'APROBADO'
GROUP BY b.ticket_sgp;
-- Borradores habilitados para carga (RN-01)
SELECT b.borrador_id FROM p1.borrador b
WHERE EXISTS (SELECT 1 FROM p1.aprobacion a WHERE a.borrador_id=b.borrador_id AND a.tipo='INGENIERO' AND a.resultado='APROBADO')
  AND EXISTS (SELECT 1 FROM p1.aprobacion a WHERE a.borrador_id=b.borrador_id AND a.tipo='AREA' AND a.resultado='APROBADO')
  AND EXISTS (SELECT 1 FROM p1.aprobacion a WHERE a.borrador_id=b.borrador_id AND a.tipo='GERENCIA' AND a.resultado='APROBADO');
```

## 5. Reglas de calidad de datos
- Idempotencia de ingesta por (onbase_doc_id, sha256).
- Legibilidad: ≥ {{50}} caracteres por página tras OCR; si no, cuarentena.
- Completitud de metadatos: `documentType`, `estado_vigencia`, `security_groups` obligatorios para indexar.
- Integridad de carga: sha256 del borrador aprobado = sha256 del contenido enviado.
- Datos personales: solo Object IDs de Entra en tablas operativas; nombres en SGP/OnBase.

## 6. Cómo debe trabajar el agente con este archivo
Cuando llegue documentación real: reemplazar `{{…}}`, recalcular §3 con los números reales, actualizar el DDL si cambian campos y reflejar los cambios en ADD §5 y en el modelo ArchiMate (vistas 13, 13b, 21 y una nueva vista 22 de consultas y consumos).
