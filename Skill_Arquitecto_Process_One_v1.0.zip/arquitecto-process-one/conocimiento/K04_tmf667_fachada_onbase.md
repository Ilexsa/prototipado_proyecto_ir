# K04 – Fachada REST alineada a TMF667 sobre la API SOAP de OnBase

> Estado: borrador de diseño. Todo atributo, ruta o valor marcado **[verificar]** debe contrastarse con la especificación TMF667 oficial que entregue el usuario (versión exacta) y con la documentación real de la API de OnBase.

## 1. TMF667 en breve
- **TMF667 Document Management** es la Open API de TM Forum para gestionar **metadatos** de documentos (partes relacionadas como autor, revisor, publicador; fecha de creación; versión; estado de ciclo de vida). La versión de producción de referencia es **v4.0.0** [verificar si la organización usa v5].
- El **contenido** del documento vive en `attachment`: por valor (`attachment.content`, binario codificado) o por referencia (`attachment.url`, p. ej. https).
- Recursos: `Document` y `DocumentSpecification` (características por tipo de documento).
- Sigue las guías de diseño **TMF630**: filtrado por atributo (`?documentType=...`, `lastUpdate.gt=...`), selección de campos (`?fields=`), paginación (`offset`, `limit`, cabeceras `X-Total-Count` / `X-Result-Count`), polimorfismo (`@type`, `@baseType`, `@schemaLocation`), `PATCH` con merge-patch, estructura de error (`code`, `reason`, `message`, `status`, `referenceError`) [verificar detalles en la versión usada].

## 2. Por qué TMF667 en Process One
- Estándar de industria telco (TM Forum), alineado con la organización.
- Desacopla a Process One (y a otros consumidores futuros) del SOAP propietario de OnBase.
- El API Gateway traduce TMF667 (REST/JSON) ↔ OnBase (SOAP/XML) y aplica cuota, mTLS y auditoría.
- Registrar como **ADR-16**: "Fachada REST de OnBase alineada a TMF667 v{{x}}", reemplazando las rutas `/onbase/v1/...` del ADD §6.3.

## 3. Operaciones de la fachada (propuesta)
Base: `https://{{host-gateway}}/tmf-api/documentManagement/v4`

| # | Operación TMF667 | Uso en Process One | Llamadas SOAP estimadas | ¿Cuota? |
|---|---|---|---|---|
| 1 | `GET /document?documentType=&lastUpdate.gt=&lifecycleState=&fields=&offset=&limit=` | Descubrimiento (carga inicial) e incremental | {{1 por página}} | {{Sí/No}} |
| 2 | `GET /document/{id}` | Metadatos + lista de attachments y relaciones (adjuntos) | {{1}} | Sí |
| 3 | `GET /document/{id}/attachment/{attachmentId}/content` **(extensión)** | Descarga del binario (evita base64 en JSON) | {{1}} | Sí |
| 4 | `POST /document` | Paso 10: crear revisión **no vigente** del documento aprobado | {{1–2}} | {{Sí}} |
| 5 | `PATCH /document/{id}` | Actualizar metadatos permitidos (nunca a estado vigente) | {{1}} | Sí |
| 6 | `GET /documentSpecification` | Catálogo de tipos documentales y características | {{1}} | {{No: caché}} |
| — | `DELETE /document/{id}` | **No se expone** a Process One | — | — |
| — | `POST /hub` (notificaciones) | Fase 2: eventos de creación/cambio si OnBase los emite; reemplazaría el polling incremental | — | — |

Reglas de negocio aplicadas en el gateway:
- `POST /document` solo acepta `lifecycleState` ∈ {{estados no vigentes, p. ej. "inReview" / "pendingPublication"}} [valores a definir con Admin OnBase]. Cualquier intento de estado vigente → **403**.
- `POST /document` exige `externalIdentifier` con el ticket SGP y `documentRelationship` hacia el documento vigente (`relationshipType: "isRevisionOf"` – convención propia [verificar]).
- Todo `429` incluye `Retry-After`. Opcional: `X-RateLimit-Remaining` (no estándar).

## 4. Modelo del recurso Document (subconjunto usado)
| Atributo TMF667 | Uso | Origen OnBase | Campo índice | Tabla SQL |
|---|---|---|---|---|
| `id` | Identificador | {{Document Handle / ID}} | `onbase_doc_id` | DOCUMENTO.onbase_doc_id |
| `href` | URL del recurso | generado por gateway | — | — |
| `name` | Título | {{Document Name / keyword Título}} | `title` | DOCUMENTO.titulo |
| `description` | Descripción | {{keyword}} | — | — |
| `documentType` | Manual / Política / Procedimiento / Instructivo | {{Document Type}} | `doc_type` | TIPO_DOCUMENTO |
| `version` | Versión/revisión | {{Revision / keyword Versión}} | `version` | VERSION_DOCUMENTO.numero_version |
| `lifecycleState` | Vigente, en revisión, derogado… | {{keyword Estado / workflow queue}} | `estado_vigencia` | DOCUMENTO.estado_vigencia |
| `creationDate` / `lastUpdate` | Fechas | {{Date Stored / Last Modified}} | `ingested_at` / filtro incremental | VERSION_DOCUMENTO.fecha_ingesta |
| `relatedParty[]` (role: owner, author, reviewer, publisher) | Dueño del proceso, autor, aprobador | {{keywords}} | — (no indexar nombres personales en contenido) | DOCUMENTO.dueno_proceso |
| `category[]` | Área, proceso | {{keywords Área, Proceso}} | `area`, `proceso` | AREA |
| `characteristic[]` (name/value) | Código documental, fecha última revisión, grupos de seguridad | {{keywords}} | `codigo_documental`, `fecha_ultima_revision`, `security_groups` | DOCUMENTO |
| `attachment[]` (id, name, mimeType, size, url, content) | Binario(s) del documento | {{páginas / rendición}} | `blob_url` | VERSION_DOCUMENTO.blob_uri |
| `documentRelationship[]` | Adjuntos (714) y revisiones | {{Related Documents / cross-reference}} | `parent_id`, `is_attachment` | ADJUNTO |
| `externalIdentifier[]` | ID OnBase original, ticket SGP | — | — | SOLICITUD_SGP.ticket_sgp |

**Decisión propuesta (ADR-17)**: los 714 adjuntos son documentos de OnBase con ID propio → se exponen como `Document` independientes con `documentRelationship` (`relationshipType: "isAttachmentOf"`, convención propia) hacia el padre; `attachment[]` se reserva para el/los binarios del mismo documento.

## 5. Procedimiento para analizar la documentación real de OnBase
1. Del WSDL/manual extraer, por operación: nombre, propósito, parámetros, respuesta, fallas (SOAP faults), límites, permisos requeridos.
2. Llenar la plantilla:

| Operación SOAP | Propósito | Entrada clave | Salida clave | Fallas | ¿Cuenta en 500 req/h? | Operación TMF667 que la usa | Llamadas por documento |
|---|---|---|---|---|---|---|---|

3. Responder explícitamente: (a) ¿existe búsqueda por fecha de modificación? (b) ¿metadatos y lista de adjuntos en una sola llamada? (c) ¿descarga del binario por página o documento completo? (d) ¿cómo se crea una **revisión no vigente** (check-in, nuevo documento en tipo de trabajo, cola de workflow)? (e) ¿la cuota es por cuenta, IP o global; ventana fija o deslizante?
4. Recalcular el presupuesto de llamadas (K05 §4) y actualizar ADD §6.3, §6.4.2 y Anexo F.
5. Mapear fallas SOAP → HTTP: no encontrado → 404; sin permiso → 403; cuota → 429; error de OnBase → 502; timeout → 504; validación → 400.

## 6. Seguridad de la fachada
- Transporte: VPN + mTLS (certificado de la API de Ingesta en Key Vault) + filtro de IP de origen.
- Identidad de aplicación: {{mTLS únicamente | OAuth 2.0 client credentials con Entra ID + mTLS}}.
- Cuenta de servicio hacia OnBase: lectura del alcance; escritura solo en {{tipo/cola de revisión}}; sin permiso de publicación.
- Auditoría de cada llamada (consumidor, operación, ID, código, latencia) hacia {{SIEM}}.

## 7. Archivo relacionado
`toolkit/openapi_fachada_onbase_tmf667.yaml`: contrato OpenAPI 3.0 borrador de la fachada (operaciones, esquemas, errores, extensiones marcadas con `x-extension: true`).
