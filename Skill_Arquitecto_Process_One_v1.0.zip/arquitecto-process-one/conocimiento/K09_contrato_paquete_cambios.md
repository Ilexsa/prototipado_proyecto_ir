# K09 – Contrato del paquete de cambios (ADD + ArchiMate)

Todo cambio al ADD, a los diagramas o al modelo ArchiMate se entrega como **un único paquete JSON**. El usuario lo pega en **Estudio_ProcessOne.html**, que lo valida, lo aplica y genera el Word, el XML para Archi y los diagramas. Si una sola operación falla, **no se aplica nada** y el Estudio devuelve los errores para corregir.

## 1. Estructura
```json
{
  "version": "0.9.2",
  "fecha": "dd/mm/aaaa",
  "descripcion": "Qué cambia y por qué, en una línea",
  "add": [ /* operaciones sobre el documento ADD (§2) */ ],
  "archimate": [ /* operaciones sobre el modelo ArchiMate (K03 §8) */ ]
}
```
- Un paquete por solicitud del usuario. Puede tener solo `add`, solo `archimate` o ambos.
- Si el cambio altera la arquitectura (componentes, integraciones, datos, roles, procesos), **siempre** incluye ambas partes para que el documento y los diagramas no se desalineen.
- Si el paquete incluye una nueva versión, la primera operación de `add` es `nueva_version`.

## 2. Operaciones sobre el ADD
Los `id` de bloque se consultan en **K08_indice_bloques_ADD.txt** (formato `id :: contenido`). Nunca inventes un id: si no está en K08, no existe.

| op | Campos | Uso |
|---|---|---|
| `nueva_version` | version, fecha, autor, descripcion, estado? | Actualiza portada, ficha y agrega fila al historial de versiones |
| `reemplazar_texto` | buscar, reemplazar, en? (id) | Reemplazo literal en todo el documento (o solo en el bloque `en`). Falla si el texto no aparece |
| `reemplazar_bloque` | id, bloque | Sustituye un bloque completo (conserva el id) |
| `insertar_bloques` | despues_de **o** antes_de (id), bloques[] | Inserta bloques nuevos; los id se generan solos |
| `eliminar_bloque` | id | Elimina un bloque |
| `mover_bloques` | ids[], despues_de **o** antes_de | Reordena bloques (p. ej., para seguir el orden de la plantilla corporativa) |
| `tabla_agregar_fila` | id, fila[], despues_de_clave? | La fila debe tener exactamente el número de columnas de la tabla (ver K08) |
| `tabla_modificar_fila` | id, clave, fila[] | `clave` = texto de la primera columna (p. ej. "ADR-10", "RF-05", "C-02") |
| `tabla_modificar_celda` | id, clave, columna (nombre del encabezado o índice), texto | Cambia una celda |
| `tabla_eliminar_fila` | id, clave | Elimina una fila |
| `lista_agregar_item` | id, item, posicion? | Viñeta nueva |
| `lista_modificar_item` | id, contiene, item | Reemplaza la primera viñeta que contenga el texto |
| `lista_eliminar_item` | id, contiene | Elimina la viñeta |
| `figura` | id, vista? ("v05" o null), caption?, maxH? | Cambia la fuente de una figura: con `vista` se dibuja desde el modelo ArchiMate |
| `modificar_meta` | campos {titulo, subtitulo, organizacion, autor, marco, clasificacion, estado} | Datos de portada/encabezado |
| `definir_valores` | valores {"{{Marcador}}": "valor"} | Solo para datos **no confidenciales** confirmados. Los confidenciales los escribe el usuario en el Estudio |

### Tipos de bloque (para `insertar_bloques` y `reemplazar_bloque`)
| t | Campos | Notas |
|---|---|---|
| `h1` | text, pb (salto de página antes, true/false) | Título de capítulo: "N. Título" |
| `h2`, `h3` | text | "N.M Título" / "N.M.K Título" |
| `p` | text | Párrafo. Formato en línea: `**negrita**`, `*cursiva*`, `` `código` ``, `{{Marcador}}` (se resalta en amarillo), `[[fig:id]]` (número de figura automático) |
| `ul` / `ol` | items[] | Viñetas / numerada |
| `table` | caption, headers[], rows[][], widths[] (proporciones) | Numeración "Tabla N." automática; cada fila con el mismo número de columnas que `headers` |
| `note` | title, text | Recuadro de nota/advertencia |
| `code` | lines[] | Código o configuración |
| `fig` | img o vista, caption, maxH? | Figura; con `vista` usa una vista del modelo ArchiMate |
| `pb` | — | Salto de página |

## 3. Reglas de calidad (revisar antes de entregar)
1. Cada `id` usado existe en K08; cada `clave` de fila existe en la tabla indicada.
2. Filas de tabla con el número exacto de columnas.
3. `reemplazar_texto` usa un fragmento literal y único (cópialo tal cual del ADD).
4. Ningún dato confidencial inventado: usa `{{Marcador}}` (K06). Nunca secretos.
5. Relaciones ArchiMate verificadas en K03-A; elementos antes que relaciones; relaciones antes que nodos y conexiones.
6. Si se agrega un componente, interfaz, dato o rol: actualizar la tabla correspondiente del ADD **y** el modelo ArchiMate en el mismo paquete.
7. Numeración de figuras y tablas: automática; en el texto usa `[[fig:ID_IMAGEN]]` en lugar de números fijos.
8. Un solo bloque ```json por respuesta, sin comentarios dentro del JSON.

## 4. Formato de respuesta del agente
1. **Resumen** (3–6 líneas): qué cambia, fuentes usadas, secciones del ADD y vistas afectadas.
2. **Paquete** en un único bloque ```json.
3. **Pendientes**: datos por levantar (marcadores) y decisiones abiertas.
4. Recordatorio breve: "Pega el paquete en el Estudio → Aplicar paquete → Word / XML".

Si el usuario pega errores del Estudio: corrige **solo** lo indicado y entrega el paquete **completo** otra vez (no un parche parcial).

## 5. Ejemplo validado (se aplica sin errores sobre la versión 0.9.1)
```json
{
 "version": "0.9.2",
 "fecha": "05/10/2026",
 "descripcion": "ADR-16: fachada REST de OnBase alineada a TMF667",
 "add": [
  {
   "op": "nueva_version",
   "version": "0.9.2",
   "fecha": "05/10/2026",
   "autor": "J. {{Apellido}}",
   "descripcion": "ADR-16: fachada REST alineada a TMF667"
  },
  {
   "op": "tabla_agregar_fila",
   "id": "t-registro-de-decisiones-de-arquitectura",
   "fila": [
    "ADR-16",
    "Fachada REST de OnBase alineada a TMF667 Document Management v{{x}}",
    "Rutas propietarias /onbase/v1",
    "Estándar TM Forum; desacopla a los consumidores del SOAP de OnBase",
    "Propuesta"
   ]
  },
  {
   "op": "insertar_bloques",
   "despues_de": "h-6.3",
   "bloques": [
    {
     "t": "p",
     "text": "Desde la versión 0.9.2 la fachada expone la API **TMF667 Document Management** (ADR-16). Base: `/tmf-api/documentManagement/v4`."
    }
   ]
  },
  {
   "op": "figura",
   "id": "f-d_sol_tb",
   "vista": "v06"
  }
 ],
 "archimate": [
  {
   "op": "modificar_elemento",
   "id": "ai_rest",
   "cambios": {
    "name": "API TMF667 Document Management (fachada OnBase)",
    "props": {
     "Estandar": "TMF667 v{{x}}"
    }
   }
  }
 ]
}
```

## 6. Ejemplos de operaciones frecuentes
```json
{"op": "tabla_modificar_celda", "id": "t-registro-de-decisiones-de-arquitectura", "clave": "ADR-10", "columna": "Estado", "texto": "Aprobada"}
{"op": "tabla_modificar_fila", "id": "t-catalogo-de-componentes", "clave": "C-02", "fila": ["C-02", "API Gateway on-prem", "{{Producto confirmado}}", "Fachada TMF667, cuota, mTLS, auditoría", "On-prem (DMZ)"]}
{"op": "reemplazar_texto", "buscar": "Usar el API Gateway corporativo existente {{producto}}", "reemplazar": "Usar el API Gateway corporativo existente {{Producto confirmado}}"}
{"op": "lista_agregar_item", "id": "ul-3.7-1", "item": "**SU-10**: la organización adopta TMF667 v{{x}}."}
{"op": "definir_valores", "valores": {"{{12}}": "15"}}
```
Todos los ejemplos de §5 y §6 se probaron contra la versión 0.9.1. En versiones posteriores confirma los id en el K08 vigente.
