# Guía de configuración – Agente "Arquitecto Process One" en Copilot Studio

Tiempo estimado: 30–45 minutos. Requiere licencia/capacidad de Copilot Studio y un entorno de Power Platform autorizado por la organización.

## 1. Crear el agente
1. Entrar a Copilot Studio con la cuenta corporativa y elegir el **entorno** autorizado (idealmente uno personal o de Arquitectura, no el de producción de Process One).
2. **Crear → Nuevo agente → Configurar** (saltar la creación conversacional).
3. **Nombre:** `Arquitecto Process One`. **Descripción:** `Asistente de arquitectura para adaptar el ADD de Process One al formato corporativo, analizar APIs de OnBase/TMF667 y mantener el modelo ArchiMate.`
4. **Instrucciones:** pegar el contenido completo de `01_instrucciones_agente.md` (≈ 5.700 caracteres; el límite de Copilot Studio es 8.000).
5. **Idioma principal:** Español.

## 2. Modelo
En la configuración del agente (sección de modelo / IA generativa) seleccionar el modelo **OpenAI** de mayor capacidad disponible en el tenant (por ejemplo, la familia GPT-5 o GPT-4.1). Mantener **orquestación generativa** activada.

## 3. Conocimiento (subir archivos)
Subir como archivos de conocimiento:
| Archivo | Propósito |
|---|---|
| `K01_contexto_process_one.md` | Contexto y decisiones del proyecto |
| `K02_guia_adaptacion_ADD.md` | Cómo adaptar al formato corporativo |
| `K03_guia_archimate_modelo_json.md` | Reglas ArchiMate, esquema JSON, relaciones permitidas |
| `K04_tmf667_fachada_onbase.md` | Diseño TMF667 sobre OnBase |
| `K05_definicion_datos_consultas_consumos.md` | Datos, consultas, consumos, DDL |
| `K06_checklist_levantamiento_datos.md` | Datos a levantar y su clasificación |
| `K07_plantillas_de_salida.md` | Formatos de entrega |
| `ADD_Process_One_v0.9.1.docx` | Documento base |
| `openapi_fachada_onbase_tmf667.yaml` | Contrato borrador de la fachada |
| `modelo_processone.json` | Modelo ArchiMate (fuente de verdad) |

Notas:
- Si Copilot Studio no acepta `.md`, `.yaml` o `.json`, cambiar la extensión a `.txt` (el contenido es texto plano).
- Agregar después, a medida que los obtengas: plantilla corporativa de ADD, WSDL/manuales de OnBase, especificación TMF667 oficial (PDF/JSON), políticas de red/seguridad. Los archivos grandes funcionan mejor como **conocimiento** (o en una biblioteca de SharePoint conectada) que como adjuntos del chat.
- Desactivar **búsqueda web** si la política de la organización lo exige; la especificación TMF667 se aporta como archivo.

## 4. Capacidades
- **Intérprete de código (Code interpreter):** activarlo en la configuración de IA generativa del agente. Permite ejecutar `generar_archimate.py`, validar el modelo y devolver el XML.
- **Carga de archivos por el usuario:** activarla para adjuntar plantillas, WSDL y el toolkit en la conversación.
- Si el intérprete de código no está disponible en el tenant: el agente entrega los fragmentos JSON y tú ejecutas el generador localmente (sección 6).

## 5. Publicación y acceso
- Canal: **Microsoft Teams** (y/o chat de prueba del portal).
- Compartir solo contigo o con el equipo de Arquitectura. Revisar políticas DLP de Power Platform del entorno.
- No subir secretos (contraseñas, PSK, certificados) ni al conocimiento ni al chat.

## 6. Ejecución local del generador (plan B o flujo normal)
```bash
# Requiere Python 3.9+; lxml es opcional (validación XSD)
pip install lxml
cd toolkit
python generar_archimate.py modelo_processone.json -o ProcessOne_ArchiMate.xml
# Solo validar sin generar:
python generar_archimate.py modelo_processone.json --solo-validar
```
Importar en Archi: **File → Import → Open Exchange XML Model…** (no usar File → Open). Luego **Save As** `.archimate`.

## 7. Ciclo de trabajo recomendado
1. Subir un documento nuevo (p. ej., WSDL de OnBase) → pedir el análisis (flujo B).
2. Pedir los cambios derivados: ADD (secciones), K05 (consumos), modelo ArchiMate (JSON).
3. Aplicar el JSON en `modelo_processone.json` (o que lo haga el intérprete de código), generar y validar el XML.
4. Importar en Archi, revisar la vista y exportar imágenes para el ADD.
5. Volver a subir al conocimiento el `modelo_processone.json` actualizado para que el agente trabaje siempre sobre la última versión.

## 8. Pruebas de aceptación del agente
Ejecutar las pruebas de `03_pruebas_y_frases_de_inicio.md`. Si alguna falla, reforzar la instrucción correspondiente o el archivo de conocimiento.
