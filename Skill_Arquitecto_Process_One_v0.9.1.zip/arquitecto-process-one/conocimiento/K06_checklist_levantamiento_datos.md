# K06 – Lista de verificación de datos a levantar en sitio

Clasificación: **P** = público/interno sin restricción, **C** = confidencial (puede ir en el ADD interno), **S** = secreto (NUNCA en documentos ni en el chat: solo referencia a Key Vault).

| # | Dato | Área responsable | Clasif. | Sección ADD | Marcador |
|---|---|---|---|---|---|
| 1 | CIDR de red corporativa y de usuarios | Redes | C | 7.3, 7.5 | {{CIDR_ONPREM}}, {{CIDR_USUARIOS}} |
| 2 | Rangos para hub y spoke en Azure (sin solapamiento) | Redes | C | 7.3 | {{CIDR_HUB}}, {{CIDR_SPOKE}} |
| 3 | Marca/modelo/firmware del dispositivo VPN; IKEv2 y BGP | Redes / Seguridad | C | 7.4 | {{Marca/Modelo}} |
| 4 | IP pública on-prem, ASN y prefijos | Redes | C | 7.4 | {{IP_PUB_ONPREM}}, {{ASN_ONPREM}} |
| 5 | Parámetros IPsec aceptados; procedimiento de intercambio de PSK | Seguridad | C (PSK = S) | 7.4 | — |
| 6 | IP/puerto de OnBase y del API Gateway; DNS corporativo y dominio | Infraestructura | C | 7.5, 7.6 | {{IP_ONBASE}}, {{IP_GATEWAY}}, {{IP_DNS_ONPREM}} |
| 7 | Ancho de banda y ventanas de mantenimiento | Redes | C | 7.4 | {{Mbps}} |
| 8 | ¿Landing zone/hub corporativo en Azure? | Nube | C | 7.1 | — |
| 9 | Versión de OnBase, WSDL/URL de servicios SOAP | Admin OnBase | C | 6.3, K04 | {{versión}} |
| 10 | Operaciones: búsqueda por tipo/fecha, metadatos, contenido, adjuntos, carga | Admin OnBase | C | 6.3, K04 | — |
| 11 | Detalle del límite 500 req/h (alcance, ventana, respuesta, consumidores que la comparten) | Admin OnBase | C | 3.6, 6.4.2 | — |
| 12 | Cuenta de servicio (lectura + escritura limitada) y autenticación | Admin OnBase / Seguridad | C (credencial = S) | 6.3 | {{svc_processone_onbase}} |
| 13 | IDs de los 574 documentos y relación con los 714 adjuntos | Ingeniería de Procesos | C | 6.4 | — |
| 14 | Formatos, páginas y tamaño promedio/máximo | Admin OnBase | P | 5.9, 12 | {{12}} págs, {{2}} MB |
| 15 | Keywords/metadatos (tipo, área, dueño, fecha de revisión, código) | Admin OnBase | C | 5.3, K04 §4 | — |
| 16 | Modelo de permisos y ambiente de pruebas | Admin OnBase / Seguridad | C | 8.5, Anexo E | — |
| 17 | Producto de API Gateway; SOAP→REST, mTLS, rate limiting; dueño | Integración | C | 6.3, ADR-10 | {{Producto}} |
| 18 | Tenant ID, suscripciones DEV/QA/PRD | Nube | C | 7.7 | {{Tenant ID}} |
| 19 | Azure Policies, regiones permitidas, nombres y etiquetas | Nube / Arquitectura | P | 7.8 | — |
| 20 | Cuota TPM y modelos habilitados en la región | Nube | C | 7.2, 12.2 | — |
| 21 | Grupos Entra ID por rol, acceso condicional, PIM | Identidad | C | 4.2, 8.1 | {{GG-…}} |
| 22 | Licencias/capacidad Copilot Studio, entorno Power Platform, DLP, VNet support | M365 | C | 6.8 | — |
| 23 | Política de publicación de apps en Teams | M365 | P | 6.8 | — |
| 24 | Acuerdo de licenciamiento y precios | Compras / FinOps | C | 12 | {{USD}} |
| 25 | Plantilla de documentos, glosario, organigrama, catálogo normativo | Ingeniería de Procesos | C | 6.7.2 | — |
| 26 | Matriz de severidad y criterios de vigencia | Ingeniería de Procesos | P | 4.6 | — |
| 27 | Golden set (documentos anotados y preguntas) | Ingeniería de Procesos | C | 9 | — |
| 28 | Clasificación de la información, aprobación DPO, residencia de datos | Seguridad / DPO | C | 5.6, ADR-05 | — |
| 29 | SIEM, ITSM y modelo de soporte | Seguridad / Operaciones | P | 8.6, 11 | {{SIEM}} |
| 30 | Estándar de desarrollo (lenguaje, repositorio, CI/CD, IaC) | Arquitectura | P | 6.6, 7.8 | — |
| 31 | Presupuesto (implementación y operación) | Patrocinador / Finanzas | C | 3.6, 12 | {{USD X}} |
| 32 | Nombres de aprobadores y stakeholders | PMO | C | Control | {{Nombre}} |
| 33 | SGP: producto, campos, estados, ¿API? | Ingeniería de Procesos / TI | C | 6.11, ADR-15 | — |
| 34 | Carga en OnBase como revisión no vigente; ¿consume cuota? | Admin OnBase | C | 6.3, SU-08 | — |
| 35 | Canal de revisión de áreas y aprobación de gerentes | Ingeniería de Procesos | P | 4.2, CU-18 | — |
| 36 | Responsable y plantilla del correo del paso 11 | Ingeniería de Procesos | P | 4.3.3 | {{Responsable}} |
| 37 | Línea base AS-IS: tiempo de ciclo y volumen anual de solicitudes | Ingeniería de Procesos | P | 3.3 | {{X}} días |
| 38 | Versión exacta de TMF667 adoptada por la organización y extensiones permitidas | Arquitectura / Integración | P | K04, ADR-16 | {{v4/v5}} |
| 39 | Formato corporativo de ADD (plantilla y campos obligatorios) | Arquitectura | P | K02 | — |

Regla para el agente: al recibir un dato, (1) clasificarlo, (2) si es S, responder que no debe compartirse y usar la referencia a Key Vault, (3) si es C/P, reemplazar el marcador en todas las secciones afectadas y listar los cambios.
