# K02 – Guía para adaptar el ADD al formato corporativo

## 1. Principio
El contenido técnico ya existe en el ADD v0.9.1. La adaptación consiste en **reubicar, renombrar y completar**, no en reescribir desde cero. Se conservan los IDs (RF, CU, RN, C, AG, ADR, R) para no romper la trazabilidad con el modelo ArchiMate.

## 2. Procedimiento
1. **Leer la plantilla** corporativa: lista de secciones, subsecciones, tablas obligatorias, campos de portada/control, anexos y reglas de estilo (numeración, estilos de título, pie de página, clasificación).
2. **Construir la matriz de correspondencia** (entregarla siempre primero):

| Sección plantilla | Contenido esperado | Fuente en ADD v0.9.1 | Estado | Acción |
|---|---|---|---|---|
| p. ej. "3. Arquitectura Actual" | Situación actual | §3.1 + §4.3.1 AS-IS | Adaptar | Fusionar y resumir |

Estados: **Completo** (se copia), **Adaptar** (existe pero cambia forma), **Falta dato** (requiere levantamiento → K06), **No aplica** (justificar), **Nuevo** (la plantilla pide algo que el ADD no tiene → redactar).

3. **Redactar** en el orden de la plantilla, respetando sus títulos exactos. Tablas del ADD se reutilizan con las columnas que pida la plantilla.
4. **Cerrar** con: lista de `{{…}}` pendientes, supuestos nuevos, ADR creados/modificados, secciones marcadas No aplica con su justificación.

## 3. Mapa del ADD v0.9.1 (para ubicar fuentes rápido)
| § | Contenido | Fase TOGAF |
|---|---|---|
| Control | Ficha, historial, aprobaciones, convención `{{}}` | — |
| 1 | Resumen ejecutivo + tabla de decisiones | — |
| 2 | Propósito, alcance (dentro/fuera), audiencia, referencias, mapeo ADM | Preliminar |
| 3 | Visión: situación actual, drivers DN, KPI, stakeholders, principios PA, restricciones RS, supuestos SU | A |
| 4 | Negocio: capacidades, actores/roles, **AS-IS/TO-BE** (4.3), ciclo de vida, CU-01..20, RN-01..14 | B |
| 5 | Datos: entidades, modelo lógico, índice AI Search, chunking, Blob, clasificación, retención, linaje, volumetría | C (datos) |
| 6 | Aplicaciones: vista general, catálogo C-xx, API Gateway, API de Ingesta, skillset, Web/Backend, multiagente, Copilot, lotes, APIs, integraciones INT-xx | C (apps) |
| 7 | Tecnología: red hub-spoke, SKUs, IPs, VPN, firewall, DNS, ambientes, nombres, IaC | D |
| 8 | Seguridad: RBAC, red, datos, IA, security trimming, STRIDE | Transversal |
| 9 | IA responsable | Transversal |
| 10 | RNF-01..16 | Requerimientos |
| 11 | Observabilidad, alertas, runbooks, continuidad | Operación |
| 12 | Costos, tokens, TPM, FinOps | — |
| 13 | ADR | — |
| 14 | Brechas | E |
| 15 | Hoja de ruta | F |
| 16 | Riesgos, dependencias | — |
| 17 | Gobierno | G/H |
| 18 | Trazabilidad | Requerimientos |
| Anexos | A Glosario, B Prompt orquestador, C Política de cuota, D Pruebas, E Mapeo permisos, F Checklist | — |

## 4. Equivalencias típicas con plantillas corporativas
| Nombre habitual en plantillas | Tomar de |
|---|---|
| Antecedentes / Contexto / Problemática | §3.1, §4.3.1 |
| Objetivos del proyecto / Beneficios | §3.2, §3.3 |
| Alcance / Fuera de alcance | §2.2 |
| Arquitectura actual (AS-IS) | §3.1, §4.3.1, figuras AS-IS |
| Arquitectura propuesta (TO-BE) | §4.3.2, §6.1, §7.1 |
| Vista lógica / de componentes | §6.1, §6.2 |
| Vista física / de despliegue / infraestructura | §7 |
| Vista de integración / interfaces | §6.3, §6.4, §6.10, §6.11, K04 |
| Vista de datos / modelo de información | §5, K05 |
| Seguridad / ciberseguridad | §8 |
| Requerimientos no funcionales / atributos de calidad | §10 |
| Alta disponibilidad / DRP / continuidad | §11.3 |
| Monitoreo / operación / soporte | §11 |
| Riesgos / supuestos / restricciones / dependencias | §3.6, §3.7, §16 |
| Decisiones de arquitectura | §13 |
| Estimación de costos / licenciamiento | §12 |
| Plan de implementación | §15 |
| Matriz RACI | construir con §4.2 (roles) + §17 |
| Diagramas | Modelo ArchiMate (K03) |

## 5. Reglas de redacción
- Voz institucional, impersonal, frases cortas. Sin marketing.
- Cada afirmación técnica debe poder rastrearse a una sección del ADD o a un documento fuente.
- Tablas antes que listas largas para catálogos.
- Los marcadores `{{…}}` se mantienen hasta tener el dato confirmado; en Word se resaltan en amarillo.
- Si la plantilla exige un campo que depende de otra área (p. ej., CMDB, número de cambio, clasificación), dejar `{{Dato – Responsable}}`.

## 6. Control de versiones
- Versión con datos reales completos: 1.0. Cambios intermedios: 0.9.x.
- Cada entrega incluye una fila de historial: versión | fecha | autor | descripción.
- Cambios que afectan decisiones → nuevo ADR (no se reescribe el anterior; se marca "Reemplazado por ADR-xx").

## 7. Lista de verificación antes de entregar
- [ ] Todas las secciones obligatorias de la plantilla tienen contenido o justificación de No aplica.
- [ ] IDs consistentes entre texto, tablas y modelo ArchiMate.
- [ ] Ningún dato confidencial inventado; ningún secreto en el documento.
- [ ] Diagramas regenerados desde el JSON con el mismo número de versión.
- [ ] Matriz de trazabilidad actualizada.
- [ ] Pendientes consolidados con responsable.
