# K01 – Contexto del proyecto Process One (estado a v0.9.1)

Documento de contexto para el agente. Resume todo lo decidido hasta la versión 0.9.1 del ADD (Documento de Definición de Arquitectura). El ADD completo está en el conocimiento como `ADD_Process_One_v0.9.1.docx`; ante duda sobre un detalle, el ADD manda.

## 1. Qué es Process One
Solución de análisis documental con IA para la documentación normativa (manuales, políticas, procedimientos) almacenada en **OnBase** (on-premises). Tiene dos canales:
- **Process One Web**: aplicación web (SPA + backend) para análisis, borradores, aprobaciones, carga a OnBase y tablero.
- **Chatbot**: agente de **Copilot Studio** publicado en **Microsoft Teams** y en una página web; delega en el agente AG-16 de Microsoft Foundry.

Rezago documental: **574 documentos desactualizados + 714 adjuntos = 1.288 objetos**.

## 2. Cadena de arquitectura (de extremo a extremo)
OnBase (API SOAP, límite 500 req/h) → **API Gateway on-premises** (fachada REST, cuota 450 req/h, mTLS) → **VPN site-to-site IPsec/IKEv2** → **Azure (hub-spoke, red privada)** → **API de Ingesta** (Azure Container Apps, token bucket 450 req/h, checkpoint en Azure SQL) → **Azure Blob Storage** (raw, quarantine, processed, outputs) → **Azure AI Search** (indexer + skillset: cracking, OCR/Document Layout, merge, split 512/64 tokens, idioma/entidades, embeddings text-embedding-3-large a 1.536 dim, índices padre/hijo, búsqueda híbrida + ranker semántico, filtro de seguridad por grupos) → **Microsoft Foundry Agent Service** (Standard Agent Setup, VNet, Cosmos DB para hilos) con modelos **Azure OpenAI** → Process One Web / Copilot Studio.

## 3. Componentes (IDs usados en todo el ADD)
| ID | Componente | Tecnología |
|---|---|---|
| C-01 | OnBase | Hyland OnBase {{versión}} – API SOAP |
| C-02 | API Gateway on-prem | {{Producto}} o APIM self-hosted gateway |
| C-03 | Conectividad híbrida | Azure VPN Gateway + dispositivo on-prem |
| C-04 | API de Ingesta | Container Apps; punto único de integración con OnBase (extracción y carga controlada) |
| C-05 | Blob Storage | StorageV2 ZRS |
| C-06 | Motor de conocimiento | Azure AI Search |
| C-07 | Modelos | Azure OpenAI en Microsoft Foundry |
| C-08 | Plataforma de agentes | Foundry Agent Service |
| C-09 | Process One Web | SPA React + TypeScript |
| C-10 | Backend Process One | ASP.NET Core .NET 8 en Container Apps |
| C-11 | Workers de análisis | Container Apps + KEDA |
| C-12 | Mensajería | Azure Service Bus (Premium por Private Endpoint; alternativa Storage Queues – ADR-13) |
| C-13 | Base operativa | Azure SQL Database |
| C-14 | Agente conversacional | Copilot Studio |
| C-15 | Identidad | Microsoft Entra ID |
| C-16 | Secretos | Key Vault |
| C-17 | Observabilidad | Azure Monitor, App Insights, Log Analytics |
| C-18 | Borde web | Application Gateway WAF v2 |
| C-19 | SGP | Sistema de tickets de solicitudes {{producto}} |

## 4. Sistema de 18 agentes (supuesto SU-01: 1 orquestador + 16 especialistas + 1 verificador)
AG-00 Orquestador · AG-01 Clasificador documental · AG-02 Ortografía y gramática · AG-03 Redacción y lenguaje claro · AG-04 Estructura y plantilla · AG-05 Vigencia y obsolescencia · AG-06 Cumplimiento normativo · AG-07 Coherencia inter-documental · AG-08 Duplicidad y similitud · AG-09 Referencias y adjuntos · AG-10 Roles y responsabilidades · AG-11 Procesos y flujo · AG-12 Controles y riesgos · AG-13 Datos personales (LOPDP) · AG-14 Terminología y glosario · AG-15 Redactor de propuesta (borrador) · AG-16 Consulta RAG (chatbot) · AG-17 Verificador de calidad (LLM-as-judge).
Patrón: orquestador–especialistas–verificador; invocación selectiva (no fan-out total); salida JSON con evidencia (cita, página, sección) y confianza. AG-16 atiende a Copilot directamente.

## 5. Proceso de negocio (AS-IS → TO-BE) – núcleo de v0.9.1
Proceso: **actualización de procesos y manuales** de Ingeniería de Procesos (11 pasos).
| # | Paso | Responsable | Cambio TO-BE |
|---|---|---|---|
| 1 | Ticket en SGP | Solicitante | Sin cambios (se registra el ticket en Process One) |
| 2 | Validación | Ingeniero de Procesos | Sin cambios |
| 3 | Asignación | Jefe de Ingeniería de Procesos | Sin cambios |
| 4 | Identificación de áreas, procesos y manuales | Ingeniero + áreas | **Chatbot** sugiere documentos potencialmente afectados |
| 5 | Sesiones de levantamiento | Ingeniero + usuarios/áreas | **Chatbot** para consultar manuales |
| 6 | Análisis y borrador | Ingeniero | **Multiagente** genera borrador; **HITL iterativo**: aprobar / observar / ajustar directo |
| 7 | Revisión por áreas | Áreas | Process One genera el documento aprobado que se envía |
| 8 | Aprobación de gerencias | Gerentes | Sin cambios (se registra) |
| 9 | Socialización | Gerencia de Procesos, Operaciones e involucradas | Sin cambios |
| 10 | Publicación en OnBase | {{Responsable}} / OnBase | **Process One carga el documento aprobado sin sustituir la vigente**; la vigencia la da el flujo de OnBase |
| 11 | Correo formal | {{Responsable}} | Sin cambios |

## 6. Decisiones clave (ADR)
ADR-01 extracción pull con cuota en gateway y cliente · ADR-02 vectorización integrada (skillset) · ADR-03 Foundry Agent Service + flujo determinista en backend para lotes · ADR-04 invocación selectiva · ADR-05 región {{East US 2}} y tipo de despliegue {{Data Zone}} (pendiente DPO) · ADR-06 Azure SQL · ADR-07 Container Apps · ADR-08 Copilot Studio conectado a AG-16 · ADR-09 web interna por App Gateway privado · ADR-10 API Gateway existente vs APIM self-hosted (pendiente) · ADR-11 embeddings 1.536 dim · ADR-12 HITL iterativo; carga solo del documento aprobado, nunca sustituye la vigente · ADR-13 Service Bus Premium vs Storage Queues (pendiente costo) · ADR-14 la carga a OnBase pasa por la API de Ingesta · ADR-15 ticket SGP manual en fase 1.
**Nueva línea de trabajo**: exponer la fachada REST del API Gateway alineada a **TMF667 Document Management** (estándar TM Forum) en lugar de rutas propietarias `/onbase/v1/...` (ver K04). Debe registrarse como ADR-16.

## 7. Cifras de dimensionamiento (supuestos a recalcular con datos reales)
- Carga inicial ≈ 1.882 llamadas (574 metadatos + 574 contenidos + 714 adjuntos + ~20 descubrimiento) → ≈ 4,2 h a 450 req/h; ≈ 7,5 h si la cuota se comparte (250 req/h).
- {{12}} páginas y {{2}} MB promedio por objeto → ≈ 7,7 M tokens de contenido, ≈ 17.300 fragmentos, ≈ 106 MB de vectores.
- Análisis del rezago ≈ 88 M tokens de entrada + 11 M de salida; ≈ 41 k TPM promedio en 5 días; cuota recomendada 120–150 k TPM.

## 8. Convenciones
- Marcadores `{{Dato}}` = dato a levantar en sitio (Anexo F / K06). Nunca reemplazarlos con valores inventados.
- IDs: RF-xx, RNF-xx, CU-xx, RN-xx, PA-xx, RS-xx, SU-xx, C-xx, AG-xx, ADR-xx, R-xx, DEP-xx, INT-xx.
- Nombres Azure (CAF): `{tipo}-p1-{amb}-{región}-{nnn}`.
- Idioma: español. Formato de fechas: dd/mm/aaaa.

## 9. Estado y pendientes
Hecho: ADD v0.9.1 (62 págs.), diagramas (PNG y fuentes), modelo ArchiMate v0.9.1 (22 vistas, 380 elementos, 704 relaciones) en JSON + XML validado.
Pendiente:
1. Adaptar el ADD al **formato corporativo** de ADD (plantilla que entregará Jonathan).
2. Incorporar datos confidenciales reales (IPs, rangos, cuentas, operaciones SOAP, SKU, cuotas, nombres).
3. Analizar la API de OnBase real y definir la fachada **TMF667**.
4. Mejorar la **definición de datos** y de **consultas y consumos** (K05).
5. Actualizar el modelo ArchiMate con todo lo anterior.

## 10. Preferencias del usuario
Salidas completas y utilizables de inmediato; comunicación concisa; nada de teoría innecesaria. Trabaja como Líder de Arquitectura; domina redes, bases de datos (SQL Server) y desarrollo (.NET, Go, PHP).
