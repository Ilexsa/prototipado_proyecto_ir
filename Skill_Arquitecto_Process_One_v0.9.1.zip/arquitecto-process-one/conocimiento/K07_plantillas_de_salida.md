# K07 – Plantillas de salida

## T1. Encabezado de toda entrega
**Objetivo:** … | **Fuentes usadas:** archivo (sección/página) | **Cambios al ADD:** §… | **Versión propuesta:** 0.9.x | **Pendientes:** …

## T2. Matriz de correspondencia plantilla ↔ ADD
| Sección plantilla | Contenido esperado | Fuente ADD v0.9.1 | Estado | Acción |
|---|---|---|---|---|

## T3. ADR
| Campo | Contenido |
|---|---|
| ID / título | ADR-xx … |
| Estado | Propuesta / Aprobada / Reemplazada por ADR-yy |
| Contexto | Problema y restricciones (citar fuente) |
| Alternativas | A…, B…, C… (pros/contras) |
| Decisión | … |
| Consecuencias | Impacto en componentes C-xx, datos, seguridad, costo |
| Secciones ADD afectadas | §… |
| Cambios ArchiMate | elementos/relaciones/vistas |

## T4. Catálogo de operaciones SOAP de OnBase
| Operación SOAP | Propósito | Entrada clave | Salida clave | Fallas | ¿Cuenta en 500 req/h? | Operación TMF667 | Llamadas por documento | Fuente |
|---|---|---|---|---|---|---|---|---|

## T5. Mapeo de datos
| OnBase (campo/keyword) | TMF667 (atributo) | Índice AI Search | Azure SQL | Transformación | Obligatorio | Clasificación |
|---|---|---|---|---|---|---|

## T6. Cambio al modelo ArchiMate
1. Resumen: qué cambia y por qué.
2. Elementos (JSON para `elements`).
3. Relaciones (JSON para `relationships`) – cada una verificada en K03-A.
4. Vista(s) (objeto completo de la vista si cambia; posiciones sin solapes).
5. Comando: `python generar_archimate.py modelo_processone.json -o ProcessOne_ArchiMate.xml`
6. Importar en Archi: File > Import > Open Exchange XML Model.

## T7. Sección de ADD (texto listo para pegar)
**N. Título exacto de la plantilla**
Párrafo introductorio (2–4 líneas) → tabla principal → notas `{{…}}` → referencias a IDs.

## T8. Pendientes
| # | Dato / decisión | Responsable | Bloquea | Sección |
|---|---|---|---|---|

## T9. Presupuesto de llamadas a OnBase
| Concepto | Fórmula | Valor | Horas a {{cuota}} req/h |
|---|---|---|---|

## T10. Frases de inicio útiles (para el usuario)
- "Adapta el ADD a esta plantilla" + adjuntar plantilla.
- "Analiza este WSDL de OnBase y actualiza el catálogo de operaciones y el presupuesto de llamadas".
- "Con esta especificación TMF667, ajusta la fachada y el OpenAPI".
- "Agrega al modelo ArchiMate la vista de consultas y consumos".
- "Estos son los rangos IP reales: actualiza §7.3, §7.5 y la vista 14".
- "Dame los pendientes para cerrar la versión 1.0".
