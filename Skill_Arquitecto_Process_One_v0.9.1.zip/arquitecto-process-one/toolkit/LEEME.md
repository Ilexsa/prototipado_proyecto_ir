# Toolkit ArchiMate y contratos – Process One

| Archivo | Uso |
|---|---|
| `generar_archimate.py` | Genera y valida el XML (Open Exchange Format 3.1) desde el JSON |
| `modelo_processone.json` | **Fuente de verdad** del modelo ArchiMate v0.9.1 (380 elementos, 704 relaciones, 22 vistas) |
| `ProcessOne_ArchiMate_v0.9.1.xml` | XML generado y validado (importar en Archi) |
| `reglas/relaciones_archimate_3_2.json` | Tabla de relaciones permitidas ArchiMate 3.2 (tomada de Archi, archimatetool/archi) |
| `xsd/` | Esquemas oficiales de The Open Group para validar el XML |
| `openapi_fachada_onbase_tmf667.yaml` | Contrato OpenAPI 3.0 borrador de la fachada REST alineada a TMF667 |

## Uso
```bash
pip install lxml            # opcional, habilita la validación XSD
python generar_archimate.py modelo_processone.json -o ProcessOne_ArchiMate.xml
```
Salida esperada: `RESULTADO: OK`. Los `AVISO` son de layout (cruces/solapes) y no impiden importar; los `ERROR` sí.

Archi: **File → Import → Open Exchange XML Model…** → luego **Save As** `.archimate`.

## Editar el modelo
Ver `K03_guia_archimate_modelo_json.md` (esquema, patrones, errores frecuentes, relaciones permitidas).
